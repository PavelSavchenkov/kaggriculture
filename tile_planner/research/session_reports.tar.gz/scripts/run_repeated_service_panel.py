"""Post-freeze coverage extension; no fitting from these source outcomes."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/repeated_service_panel_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar", "pack_bank", "check_life_day_cache"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    cases = [row for row in json.loads((EXP / "runs/final_panel_001/IMPORTS.json").read_text()) if row["team_id"] == 16730612]
    for case in cases:
        name = f"{case['episode']}_{case['seat']}"
        case["imported"] = str(EXP / "runs" / ("repeated_lives_001_" + name))
        assert json.loads((Path(case["imported"]) / "SUMMARY.json").read_text())["biological_contract_verified"]
        folder = OUTPUT / name; folder.mkdir()
        (folder / "BANK.txt").write_text((EXP / "runs/final_panel_001/BASE_BANK.txt").read_text().rstrip() + "\n" + str(EXP / case["folder"] / "source") + "\n")
        (folder / "validate.txt").write_text(str(EXP / case["folder"] / "source") + "\n")
        with (folder / "bank.log").open("w") as stream:
            subprocess.run([str(OUTPUT / "pack_bank"), str(folder / "BANK.txt"), str(folder / "BANK.bin"), str(folder / "validate.txt")], check=True, stdout=stream, stderr=subprocess.STDOUT)
    tasks = [{**case, "method_opponent": opponent, "warm": warm} for case in cases for opponent in ["recorded", "public_router"] for warm in [0.1, 9]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "scope": "mechanical repeated-service input extension after frozen final rejection; report separately from the frozen final method",
        "change": "version four explicitly preserves every repeated fertilization and its input consumption; assignment, dates, work order and output remain supplied",
        "settings": "same original-layout brief/full compilation settings as final_panel_001; no placement or conditional rule fitted",
        "binary_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in OUTPUT.iterdir() if p.is_file()}}, indent=2) + "\n")

    def run(task):
        parent = OUTPUT / f"{task['episode']}_{task['seat']}"
        folder = parent / f"{task['method_opponent']}_{task['warm']}"
        options = ["--seat", task["seat"], "--opponent", task["method_opponent"], "--bank", parent / "BANK.bin", "--warm_seconds", task["warm"], "--repair_preparation", 1, "--finance_source", EXP / task["folder"] / "source"]
        if task["method_opponent"] == "recorded":
            options += ["--opponent_trace", EXP / task["trace"]]
        command = [OUTPUT / "compile_cold", Path(task["imported"]) / "INPUT.plan", folder, Path(task["imported"]) / "assignment.txt", 9, 3, task["seed"], 0.005, *options]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(list(map(str, command)), stdout=stream, stderr=subprocess.STDOUT, timeout=600)
        row = {"episode": task["episode"], "seat": task["seat"], "method": f"{task['method_opponent']}_{task['warm']}", "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                result = subprocess.run(list(map(str, [OUTPUT / "export_calendar", folder, task["seed"], 0.005, task["seat"], folder / "calendar"])), stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = result.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")
    (OUTPUT / "cache_inputs.txt").write_text("".join(str(Path(case["imported"]) / "INPUT.plan") + "\n" for case in cases))
    (OUTPUT / "cache_finance.txt").write_text("".join(str(EXP / case["folder"] / "source") + "\n" for case in cases))
    with (OUTPUT / "cache.log").open("w") as stream:
        subprocess.run(list(map(str, [OUTPUT / "check_life_day_cache", OUTPUT / "cache_inputs.txt", OUTPUT / "CACHE.json", OUTPUT / "cache_finance.txt"])), check=True, stdout=stream, stderr=subprocess.STDOUT)


if __name__ == "__main__":
    main()
