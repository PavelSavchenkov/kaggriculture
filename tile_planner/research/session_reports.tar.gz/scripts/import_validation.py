"""Extract and verify a reserved replay corpus without selecting on outcomes."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(exist_ok=False)
    games = json.loads(args.manifest.read_text())["games"]
    cases = [{**seat, "episode": game["episode"], "trace": game["trace"]}
             for game in games for seat in game["seats"]]
    names = ["extract_course", "replay_course", "profile_trace", "probe_swaps", "certify_course"]
    for name in names:
        shutil.copy2(EXP / "build" / name, output / name)
    layout = output / "identity.layout.txt"
    layout.write_text(" ".join(map(str, range(100))) + "\n")
    protocol = {"cases": cases, "workers": 2, "selection": "all downloaded reserved validation courses",
                "binary_sha256": {name: hashlib.sha256((output / name).read_bytes()).hexdigest() for name in names}}
    (output / "PROTOCOL.json").write_text(json.dumps(protocol, indent=2) + "\n")

    def run(case):
        folder = output / f"{case['episode']}_{case['seat']}"
        trace = EXP / case["trace"]
        commands = [
            [output / "extract_course", trace, case["seat"], folder, "discard_accounting"],
            [output / "replay_course", trace, case["seat"], folder, layout, folder / "REPLAY_native.json", "native"],
            [output / "profile_trace", trace, case["seat"], folder / "profile"],
            [output / "probe_swaps", folder, folder / "probes"],
        ]
        with folder.with_suffix(".log").open("w") as stream:
            for command in commands:
                result = subprocess.run(list(map(str, command)), stdout=stream, stderr=subprocess.STDOUT)
                if result.returncode:
                    return {**case, "error": "command failed", "command": list(map(str, command)), "returncode": result.returncode}
        row = {**case, **json.loads((folder / "SUMMARY.json").read_text()),
               "course": str(folder.relative_to(EXP)), "replay": json.loads((folder / "REPLAY_native.json").read_text())}
        print(json.dumps({"episode": case["episode"], "team": case["team"], "valid_days": row["valid_day_contracts"],
                          "full_valid": row["replay"]["valid"]}), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, cases))
    (output / "MANIFEST.json").write_text(json.dumps({"courses": rows}, indent=2) + "\n")
    print(json.dumps({"courses": len(rows), "errors": sum("error" in row for row in rows)}), flush=True)


if __name__ == "__main__":
    main()
