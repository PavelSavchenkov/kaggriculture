"""Describe successful source work and tile roles; never infer policy code from a replay."""
import collections
import hashlib
import json
import statistics
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def signature(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":"), sort_keys=True).encode()).hexdigest()


def distance(cell):
    x, y = cell % 10, cell // 10
    return min(abs(x - sx) + abs(y - sy) for sx, sy in [(4, 4), (5, 4), (4, 5), (5, 5)])


def role(state):
    if state["animal"] >= 0:
        return f"animal_{state['animal']}"
    if state["crop"] >= 0:
        return f"crop_{state['crop']}"
    return None


def main():
    rows = json.loads((EXP / "runs/validation_sources_001/MANIFEST.json").read_text())["courses"]
    profiles = []
    for row in rows:
        if not row.get("source_parity"):
            continue
        days = [json.loads((EXP / row["course"] / f"{d:02}/problem.json").read_text()) for d in range(30)]
        roles = [set() for _ in range(100)]
        radius = collections.defaultdict(list)
        calendar, work_calendar = [], []
        for d, day in enumerate(days):
            snapshot = []
            for cell, tile in enumerate(day["start"]["managed_tiles"]):
                label = role(tile["state"])
                if label:
                    roles[cell].add(label)
                    radius[label.split("_")[0]].append(distance(cell))
                    radius[label].append(distance(cell))
                snapshot.append(label)
            calendar.append(snapshot)
            work_calendar.append(sorted((work["tile"], [(a["op"], a["arg"], a["output_quantity"]) for a in work["actions"]]) for work in day["tile_work"]))
        active = [labels for labels in roles if labels]
        profile = {**row, "role_calendar_hash": signature(calendar), "work_calendar_hash": signature(work_calendar),
                   "early_work_hash": signature(work_calendar[:3]), "day3_roles_hash": signature(calendar[3]),
                   "day10_roles_hash": signature(calendar[10]), "day20_roles_hash": signature(calendar[20]),
                   "used_tiles": len(active), "single_role_tiles": sum(len(labels) == 1 for labels in active),
                   "single_coarse_role_tiles": sum(len({label.split("_")[0] for label in labels}) == 1 for labels in active),
                   "mean_radius": {label: statistics.mean(values) for label, values in sorted(radius.items())},
                   "tile_roles": [sorted(labels) for labels in roles], "daily_roles": calendar}
        profiles.append(profile)
    by_team = collections.defaultdict(list)
    by_work = collections.defaultdict(list)
    for profile in profiles:
        by_team[profile["team"]].append(profile)
        by_work[profile["work_calendar_hash"]].append(f"{profile['team']}:{profile['episode']}:{profile['seat']}")
    summary = {}
    for team, cases in sorted(by_team.items()):
        summary[team] = {"courses": len(cases), "fully_supported_courses": sum(p["valid_day_contracts"] == 30 for p in cases),
                         "distinct_work_calendars": len({p["work_calendar_hash"] for p in cases}),
                         "distinct_early_work": len({p["early_work_hash"] for p in cases}),
                         "distinct_day3_layouts": len({p["day3_roles_hash"] for p in cases}),
                         "distinct_day10_layouts": len({p["day10_roles_hash"] for p in cases}),
                         "distinct_day20_layouts": len({p["day20_roles_hash"] for p in cases}),
                         "single_role_fraction": sum(p["single_role_tiles"] for p in cases) / sum(p["used_tiles"] for p in cases),
                         "single_crop_or_animal_role_fraction": sum(p["single_coarse_role_tiles"] for p in cases) / sum(p["used_tiles"] for p in cases),
                         "mean_animal_radius": statistics.mean(p["mean_radius"].get("animal", 0) for p in cases),
                         "mean_crop_radius": statistics.mean(p["mean_radius"].get("crop", 0) for p in cases),
                         "hire_bill_mean": statistics.mean(p["source_hire_bill"] for p in cases)}
    output = EXP / "research" / "validation_source_profiles"
    output.mkdir(exist_ok=True)
    (output / "profiles.json").write_text(json.dumps(profiles, indent=2) + "\n")
    (output / "SUMMARY.json").write_text(json.dumps({"teams": summary, "identical_work_groups": [v for v in by_work.values() if len(v) > 1]}, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
