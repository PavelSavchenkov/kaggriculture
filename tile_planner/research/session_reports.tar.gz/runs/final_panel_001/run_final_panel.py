"""Frozen final replay import, compilation and bounded placement comparison."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/final_panel_001"
NAMES = ["extract_course", "replay_course", "import_lives", "pack_bank", "compile_cold", "export_calendar", "probe_lives", "solve_point", "check_life_day_cache"]


def main():
    global EXP, OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["freeze", "import", "compile", "optimize", "cache"])
    parser.add_argument("--experiment", type=Path, default=EXP)
    parser.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    EXP = args.experiment.resolve()
    OUTPUT = EXP / "runs/final_panel_001"
    if args.manifest is None:
        args.manifest = EXP / "research/final_placement_traces_v1/MANIFEST.json"
    if args.stage == "freeze":
        OUTPUT.mkdir(exist_ok=False)
        tools = OUTPUT / "tools"; tools.mkdir()
        for name in NAMES:
            shutil.copy2(EXP / "build" / name, tools / name)
        shutil.copy2(EXP / "scripts/optimize_placement.py", OUTPUT / "optimize_placement.py")
        shutil.copy2(Path(__file__), OUTPUT / "run_final_panel.py")
        shutil.copy2(EXP / "runs/replay_bank_001.txt", OUTPUT / "BASE_BANK.txt")
        (OUTPUT / "identity.layout.txt").write_text(" ".join(map(str, range(100))) + "\n")
        (OUTPUT / "PROTOCOL.json").write_text(json.dumps({
            "selection": "two latest complete episodes of the highest-public-score submission for each previously reserved final team: cooked, pensukesan, Terry, Blurry; no outcome filtering",
            "teams": [16850683, 16748173, 16689430, 16730612], "workers": 4,
            "input": "exact source parity, identity replay, then fixed accepted biology/land/trades; report every rejected import and failed compile",
            "bank": "frozen development bank source list plus this case's supplied original source certificate; no other final case",
            "compile": {"opponents": ["recorded original continuation", "live public_router"], "warm_seconds": [0.1, 9], "day_seconds": 9, "query_seconds": 3, "preparation_repair": True, "seed_and_seat": "original", "weed_chance": 0.005},
            "optimize": {"seconds": 180, "modes": ["fixed", "search"], "objective": "cash", "seed": 9013,
                "incumbent": "highest-cash complete original-layout live compile among brief/full refinement; ties prefer lower bill then full refinement; report cases with no incumbent",
                "bank": "only the supplied incumbent and within-run discoveries; complete calendar verification before acceptance"},
            "cache": "same 256 distinct assignment proposals per imported input; exact cached/uncached score equality with fixed finance",
            "promotion": "existing PROTOCOL.md gates; related teams are not independent families; no tuning from final outcomes",
            "binary_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in tools.iterdir()},
            "launcher_sha256": hashlib.sha256((OUTPUT / "optimize_placement.py").read_bytes()).hexdigest(),
            "panel_sha256": hashlib.sha256((OUTPUT / "run_final_panel.py").read_bytes()).hexdigest()}, indent=2) + "\n")
        return

    def command(arguments, log, timeout=600):
        with log.open("w") as stream:
            try:
                return subprocess.run(list(map(str, arguments)), stdout=stream, stderr=subprocess.STDOUT, timeout=timeout).returncode
            except subprocess.TimeoutExpired:
                return "timeout"

    def tool(name, arguments, log, timeout=600):
        return command([OUTPUT / "tools" / name, *arguments], log, timeout)

    if args.stage == "import":
        games = json.loads(args.manifest.read_text())["games"]
        cases = [{**seat, "episode": game["episode"], "trace": game["trace"], "seed": int((EXP / game["trace"]).read_text().split()[0])}
            for game in games for seat in game["seats"]]
        (OUTPUT / "INPUT_MANIFEST.json").write_text(json.dumps(cases, indent=2) + "\n")

        def run(case):
            folder = OUTPUT / f"{case['episode']}_{case['seat']}"; folder.mkdir(exist_ok=False)
            row = {**case, "folder": str(folder.relative_to(EXP))}
            source = folder / "source"; imported = folder / "lives"
            operations = [
                ("extract_course", [EXP / case["trace"], case["seat"], source, "discard_accounting"], "extract"),
                ("replay_course", [EXP / case["trace"], case["seat"], source, OUTPUT / "identity.layout.txt", folder / "SOURCE_REPLAY.json", "native"], "identity"),
                ("import_lives", [source, imported], "import"),
            ]
            for name, arguments, label in operations:
                code = tool(name, arguments, folder / f"{label}.log")
                row[label + "_returncode"] = code
                if code:
                    row["failure"] = label
                    break
            if (imported / "SUMMARY.json").exists():
                row.update(json.loads((imported / "SUMMARY.json").read_text()))
            if row.get("biological_contract_verified"):
                (folder / "BANK.txt").write_text((OUTPUT / "BASE_BANK.txt").read_text().rstrip() + "\n" + str(source) + "\n")
                (folder / "bank_validate.txt").write_text(str(source) + "\n")
                row["bank_returncode"] = tool("pack_bank", [folder / "BANK.txt", folder / "BANK.bin", folder / "bank_validate.txt"], folder / "bank.log")
            (folder / "IMPORT.json").write_text(json.dumps(row, indent=2) + "\n")
            print(json.dumps(row), flush=True)
            return row

        with ThreadPoolExecutor(max_workers=2) as pool:
            rows = list(pool.map(run, cases))
        (OUTPUT / "IMPORTS.json").write_text(json.dumps(rows, indent=2) + "\n")
        return

    cases = json.loads((OUTPUT / "IMPORTS.json").read_text())
    valid = [case for case in cases if case.get("biological_contract_verified") and case.get("bank_returncode") == 0]
    if args.stage == "cache":
        inputs = OUTPUT / "cache_inputs.txt"; finance = OUTPUT / "cache_finance.txt"
        inputs.write_text("".join(str(EXP / case["folder"] / "lives/INPUT.plan") + "\n" for case in valid))
        finance.write_text("".join(str(EXP / case["folder"] / "source") + "\n" for case in valid))
        code = tool("check_life_day_cache", [inputs, OUTPUT / "CACHE.json", finance], OUTPUT / "cache.log")
        if code:
            raise RuntimeError("final cache check failed")
        return

    if args.stage == "compile":
        tasks = [{**case, "opponent": opponent, "warm": warm} for case in valid for opponent in ["recorded", "public_router"] for warm in [0.1, 9]]

        def run(task):
            parent = EXP / task["folder"]; folder = parent / f"{task['opponent']}_{task['warm']}"
            options = ["--opponent", task["opponent"], "--seat", task["seat"], "--finance_source", parent / "source", "--bank", parent / "BANK.bin", "--warm_seconds", task["warm"], "--repair_preparation", 1]
            if task["opponent"] == "recorded":
                options += ["--opponent_trace", EXP / task["trace"]]
            code = tool("compile_cold", [parent / "lives/INPUT.plan", folder, parent / "lives/assignment.txt", 9, 3, task["seed"], 0.005, *options], folder.with_suffix(".log"))
            row = {"episode": task["episode"], "seat": task["seat"], "team": task["team"], "method": f"{task['opponent']}_{task['warm']}", "output": str(folder.relative_to(EXP)), "returncode": code}
            if (folder / "SUMMARY.json").exists():
                row.update(json.loads((folder / "SUMMARY.json").read_text()))
            if row.get("complete"):
                row["calendar_verified"] = tool("export_calendar", [folder, task["seed"], 0.005, task["seat"], folder / "calendar"], folder / "calendar.log") == 0
            folder.mkdir(exist_ok=True)
            (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
            print(json.dumps(row), flush=True)
            return row

        with ThreadPoolExecutor(max_workers=4) as pool:
            rows = list(pool.map(run, tasks))
        (OUTPUT / "COMPILES.json").write_text(json.dumps(rows, indent=2) + "\n")
        return

    compiled = json.loads((OUTPUT / "COMPILES.json").read_text())
    incumbents = []
    for case in cases:
        candidates = [row for row in compiled if row["episode"] == case["episode"] and row["seat"] == case["seat"] and row["method"].startswith("public_router_") and row.get("complete") and row.get("calendar_verified")]
        if candidates:
            incumbents.append(min(candidates, key=lambda row: (-row["cash"], row["hire_bill"], row["method"].endswith("0.1"))))
    (OUTPUT / "INCUMBENTS.json").write_text(json.dumps({"all_cases": len(cases), "with_incumbent": len(incumbents), "cases": incumbents}, indent=2) + "\n")
    tasks = [{**case, "mode": mode} for case in incumbents for mode in ["fixed", "search"]]

    def run(task):
        folder = EXP / task["output"]
        output = folder.parent / ("bounded_" + task["mode"])
        code = command(["python", OUTPUT / "optimize_placement.py", folder, output, "--seconds", 180, "--mode", task["mode"], "--objective", "cash", "--seed", 9013, "--tools", OUTPUT / "tools"], output.with_suffix(".log"), 210)
        row = {"team": task["team"], "episode": task["episode"], "seat": task["seat"], "mode": task["mode"], "returncode": code, "output": str(output.relative_to(EXP))}
        if (output / "RESULT.json").exists():
            row.update(json.loads((output / "RESULT.json").read_text()))
        print(json.dumps({k: v for k, v in row.items() if k != "events"}), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "BOUNDED.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
