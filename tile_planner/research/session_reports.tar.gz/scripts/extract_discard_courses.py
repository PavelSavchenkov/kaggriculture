"""Versioned physical contracts that explicitly account for source shed discard."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/source_courses_v2"


def main():
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    cases = json.loads((EXP / "runs/source_courses/MANIFEST.json").read_text())["courses"]
    traces = {game["episode"]: game["trace"] for game in games}
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/extract_course", OUTPUT / "extract_course")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": cases, "workers": 4,
        "endpoint": "physical end = actual source end + per-item discarded stock; next-day starts remain actual source states",
        "full_engine_validation": "still required; matching physical endpoints does not prove matching real capacity losses",
        "binary_sha256": hashlib.sha256((OUTPUT / "extract_course").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}"
        with folder.with_suffix(".log").open("w") as stream:
            completed = subprocess.run([str(OUTPUT / "extract_course"), str(EXP / traces[case["episode"]]), str(case["seat"]),
                str(folder), "discard_accounting"], stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "returncode": completed.returncode, "course": str(folder.relative_to(EXP)), "original_valid_days": case["valid_day_contracts"]}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, cases))
    (OUTPUT / "MANIFEST.json").write_text(json.dumps({"courses": rows}, indent=2) + "\n")


if __name__ == "__main__":
    main()
