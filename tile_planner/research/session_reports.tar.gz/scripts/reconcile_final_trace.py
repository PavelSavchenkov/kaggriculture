"""Repeat the frozen test for the source rejected by malformed-action encoding."""
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
PANEL = EXP / "runs/final_panel_001"


def main():
    previous = json.loads((PANEL / "IMPORTS.json").read_text())
    case = next(row for row in previous if row["episode"] == 107375112 and row["seat"] == 1)
    case = {key: case[key] for key in ["episode", "seat", "team", "team_id", "seed", "replay_team_name"]}
    case["trace"] = "research/final_placement_traces_v2/107375112.txt"
    folder = PANEL / "corrected_107375112_1"; folder.mkdir(exist_ok=False)
    case["folder"] = str(folder.relative_to(EXP))
    source = folder / "source"; imported = folder / "lives"

    def run(name, arguments, log):
        with log.open("w") as stream:
            return subprocess.run([str(PANEL / "tools" / name), *map(str, arguments)], stdout=stream, stderr=subprocess.STDOUT, timeout=600).returncode

    operations = [
        ("extract_course", [EXP / case["trace"], 1, source, "discard_accounting"], "extract"),
        ("replay_course", [EXP / case["trace"], 1, source, PANEL / "identity.layout.txt", folder / "SOURCE_REPLAY.json", "native"], "identity"),
        ("import_lives", [source, imported], "import"),
    ]
    for name, arguments, label in operations:
        code = run(name, arguments, folder / f"{label}.log")
        case[label + "_returncode"] = code
        if code:
            case["failure"] = label
            break
    if (imported / "SUMMARY.json").exists():
        case.update(json.loads((imported / "SUMMARY.json").read_text()))
    (folder / "IMPORT.json").write_text(json.dumps(case, indent=2) + "\n")
    if not case.get("biological_contract_verified"):
        return
    (folder / "BANK.txt").write_text((PANEL / "BASE_BANK.txt").read_text().rstrip() + "\n" + str(source) + "\n")
    (folder / "bank_validate.txt").write_text(str(source) + "\n")
    case["bank_returncode"] = run("pack_bank", [folder / "BANK.txt", folder / "BANK.bin", folder / "bank_validate.txt"], folder / "bank.log")
    (folder / "IMPORT.json").write_text(json.dumps(case, indent=2) + "\n")
    if case["bank_returncode"]:
        raise RuntimeError("corrected final source bank check failed")
    (folder / "PROTOCOL.json").write_text(json.dumps({"case": case,
        "correction": "The root Python encoder interpreted missing item arguments as WHEAT. The local converter now uses invalid item 255 for PICKUP/PLACE/PLANT with no valid string item. The raw replay, selected team/episode and frozen optimization binaries are unchanged.",
        "original_failure": "full-state parity mismatch at step 94; rival action was bare PLACE",
        "method": "exactly the final_panel_001 frozen four compile settings and budget", "workers": 2}, indent=2) + "\n")

    def compile_one(task):
        opponent, warm = task; output = folder / f"{opponent}_{warm}"
        options = ["--opponent", opponent, "--seat", 1, "--finance_source", source, "--bank", folder / "BANK.bin", "--warm_seconds", warm, "--repair_preparation", 1]
        if opponent == "recorded":
            options += ["--opponent_trace", EXP / case["trace"]]
        code = run("compile_cold", [imported / "INPUT.plan", output, imported / "assignment.txt", 9, 3, case["seed"], 0.005, *options], output.with_suffix(".log"))
        row = {"episode": case["episode"], "seat": 1, "team": case["team"], "method": f"{opponent}_{warm}", "output": str(output.relative_to(EXP)), "returncode": code}
        if (output / "SUMMARY.json").exists():
            row.update(json.loads((output / "SUMMARY.json").read_text()))
        if row.get("complete"):
            row["calendar_verified"] = run("export_calendar", [output, case["seed"], 0.005, 1, output / "calendar"], output / "calendar.log") == 0
        output.mkdir(exist_ok=True)
        (output / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(compile_one, [(opponent, warm) for opponent in ["recorded", "public_router"] for warm in [0.1, 9]]))
    (folder / "COMPILES.json").write_text(json.dumps(rows, indent=2) + "\n")
    (folder / "cache_inputs.txt").write_text(str(imported / "INPUT.plan") + "\n")
    (folder / "cache_finance.txt").write_text(str(source) + "\n")
    if run("check_life_day_cache", [folder / "cache_inputs.txt", folder / "CACHE.json", folder / "cache_finance.txt"], folder / "cache.log"):
        raise RuntimeError("corrected final source cache check failed")


if __name__ == "__main__":
    main()
