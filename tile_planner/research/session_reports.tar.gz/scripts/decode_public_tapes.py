"""Read the Apache-2.0 yhay81 tapes embedded in prvsiyan's archived source.

Decode literal data only. Never execute notebook or agent code.
"""
import ast
import base64
import hashlib
import json
import lzma
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    source = EXP / "research/source_review/kaggriculture-frontier-the-soil-remembers-rain_AGENT_SOURCE.txt"
    tree = ast.parse(source.read_text())
    node = next(n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "_INLINE_TAPES" for t in n.targets))
    call = next(n for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "b85decode")
    decoder = lzma.LZMADecompressor()
    raw = decoder.decompress(base64.b85decode(ast.literal_eval(call.args[0])), max_length=10000000)
    assert decoder.eof
    value = json.loads(raw)
    output = EXP / "research/source_review/shop_router_0909_tapes.json"
    output.write_text(json.dumps(value, separators=(",", ":")) + "\n")
    provenance = {"original_author": "yhay81", "original_url": "https://www.kaggle.com/code/yhay81/shop-router-0909",
                  "license": "Apache-2.0, retained in archived source", "packaging_author": "prvsiyan",
                  "source": str(source.relative_to(EXP)), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                  "decoded_sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "executed": False}
    output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print("decoded bytes", len(raw), "type", type(value).__name__, "length", len(value))
    print("first entry", str(value[0])[:700] if isinstance(value, list) else list(value))


if __name__ == "__main__":
    main()
