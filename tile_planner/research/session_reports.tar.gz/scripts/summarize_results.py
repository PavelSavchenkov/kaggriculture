"""Rebuild the compact result index from preserved experiment reports."""
import hashlib
import json
import statistics
from collections import defaultdict
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
SOURCES = {}


def read(name):
    path = EXP / name
    SOURCES[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text())


def describe(values):
    values = sorted(values)
    n = len(values)
    position = 0.95 * (n - 1)
    lower = int(position)
    p95 = values[lower] + (position - lower) * (values[min(lower + 1, n - 1)] - values[lower])
    return {"n": n, "sum": sum(values), "mean": statistics.mean(values), "median": statistics.median(values), "p95": p95, "max": max(values)}


def bounded(name, seconds=None):
    rows = read(name)
    if seconds is not None:
        rows = [row for row in rows if row["budget_seconds"] == seconds]
    pairs = defaultdict(dict)
    for row in rows:
        case = str(row.get("case", row.get("episode")))
        pairs[case][row["mode"]] = row
    output = []
    for case, modes in pairs.items():
        fixed, search = modes["fixed"], modes["search"]
        assert fixed["original_cash"] == search["original_cash"]
        assert fixed["original_hire_bill"] == search["original_hire_bill"]
        output.append({"case": case, "fixed_gain": fixed["cash_change"], "search_gain": search["cash_change"],
            "search_minus_fixed_cash": search["cash"] - fixed["cash"], "fixed_bill": fixed["hire_bill"], "search_bill": search["hire_bill"],
            "both_inputs_reverified": fixed.get("input_reverified", True) and search.get("input_reverified", True)})
    return {"source": name, "cases": output, "wins_ties_losses": [sum(row["search_minus_fixed_cash"] > 0 for row in output), sum(row["search_minus_fixed_cash"] == 0 for row in output), sum(row["search_minus_fixed_cash"] < 0 for row in output)], "maximum_internal_overrun_seconds": max(0, max(row["elapsed_seconds"] - row["budget_seconds"] for row in rows))}


def main():
    result = {"scope": "preserved development, reserved and separately labeled post-freeze results; no broad placement-quality promotion"}
    result["bounded"] = {
        "synthetic_development_180": bounded("runs/bounded_panel_002/SUMMARY.json", 180),
        "replay_development_180": bounded("runs/real_bounded_panel_002/SUMMARY.json"),
        "frozen_final_180": bounded("runs/final_panel_001/BOUNDED.json"),
        "distinct_family_extension_180": bounded("runs/distinct_bounded_panel_001/SUMMARY.json")}
    imports = read("runs/final_panel_001/IMPORTS.json")
    compiles = read("runs/final_panel_001/COMPILES.json")
    result["frozen_final_coverage"] = {"selected_inputs": len(imports), "biological_inputs_supported": sum(bool(row.get("biological_contract_verified")) for row in imports), "compile_attempts_supported_inputs": len(compiles), "engine_complete": sum(bool(row.get("complete")) for row in compiles), "original_calendar_verified": sum(bool(row.get("calendar_verified")) for row in compiles), "rows": [{k: row.get(k) for k in ["episode", "seat", "method", "returncode", "complete", "calendar_verified", "hire_bill", "cash", "failure", "output"]} for row in compiles]}
    repeated = read("runs/repeated_service_panel_001/SUMMARY.json")
    result["repeated_service_extension"] = {"inputs": 2, "attempts": len(repeated), "verified_complete": sum(bool(row.get("complete") and row.get("calendar_verified")) for row in repeated), "rows": [{k: row.get(k) for k in ["episode", "method", "complete", "hire_bill", "cash", "failure", "output"]} for row in repeated]}
    result["cache"] = {}
    for label, paths in {
        "synthetic_18": ["runs/life_day_cache_001.json"],
        "development_fixed_finance_6": ["runs/replay_life_day_cache_fixed_002.json"],
        "frozen_final_6": ["runs/final_panel_001/CACHE.json", "runs/final_panel_001/corrected_107375112_1/CACHE.json"],
        "repeated_extension_2": ["runs/repeated_service_panel_001/CACHE.json"]}.items():
        values = [read(path) for path in paths]
        slow = sum(value["slow_seconds"] for value in values)
        fast = sum(value["fast_seconds"] for value in values)
        result["cache"][label] = {"assignments": sum(value["checked"] for value in values), "bit_exact": all(value["bit_exact"] for value in values), "uncached_seconds": slow, "cached_seconds": fast, "time_reduction_fraction": 1 - fast / slow, "sources": paths}
    rows = read("runs/bank_format_benchmark_001/SUMMARY.json")
    by_format = {kind: [row for row in rows if row["format"] == kind] for kind in ["txt", "bin"]}
    pairs = {(row["case"], row["repeat"]): row for row in by_format["txt"]}
    exact = all(all(row[field] == pairs[row["case"], row["repeat"]][field] for field in ["complete", "hire_bill", "cash", "opponent_cash"]) for row in by_format["bin"])
    result["packed_bank"] = {"runs": len(rows), "pairs": len(pairs), "outcomes_exact": exact, "engine_complete": sum(row["complete"] for row in rows), "process_seconds": {kind: describe([row["process_seconds"] for row in part]) for kind, part in by_format.items()}, "prior_construction_included": False}
    if (EXP / "runs/bank_format_benchmark_001/POSTCHECK.json").exists():
        checked = read("runs/bank_format_benchmark_001/POSTCHECK.json")
        result["packed_bank"]["separate_financial_check"] = {"checked": len(checked["rows"]), "all_verified": checked["all_verified"]}
    for label, path, field in [("real_small_bank_format", "runs/real_bank_format_001/SUMMARY.json", "format"), ("real_lifetime_compile_reuse", "runs/life_compile_reuse_benchmark_001/SUMMARY.json", "variant")]:
        if not (EXP / path).exists():
            continue
        panel = read(path)
        grouped = defaultdict(list)
        for row in panel["rows"]:
            grouped[row[field]].append(row)
        result[label] = {"all_complete_verified": panel["all_complete_verified"], "paired_actions_and_outcomes_identical": panel["paired_actions_and_outcomes_identical"], "variants": {kind: {
            "runs": len(part), "compile_seconds": describe([row["measured_compile_seconds"] for row in part]),
            "total_seconds": describe([row["measured_total_seconds"] for row in part]),
            "compile_cpu_seconds": sum(row["process_profile"]["user_seconds"] + row["process_profile"]["system_seconds"] for row in part),
            "max_rss_kib": max(row["process_profile"]["max_rss_kib"] for row in part)} for kind, part in grouped.items()}}
    if (EXP / "runs/life_compile_reuse_001/CHECK.json").exists():
        checked = read("runs/life_compile_reuse_001/CHECK.json")
        result["lifetime_oracle_reuse_check"] = {"plans": len(checked["cases"]), "lifetimes": checked["checked_lives"], "days": checked["checked_days"], "all_states_and_work_exact": checked["all_states_and_work_exact"], "unique_specs": sum(case["oracle_calls"] for case in checked["cases"])}
    if (EXP / "runs/bank_amortization_001/SUMMARY.json").exists():
        panel = read("runs/bank_amortization_001/SUMMARY.json")
        result["bank_amortization"] = {key: value for key, value in panel.items() if key != "rows"}
    curve = EXP / "runs/refinement_curve_001/SUMMARY.json"
    if curve.exists():
        rows = read("runs/refinement_curve_001/SUMMARY.json")
        grouped = defaultdict(list)
        for row in rows:
            grouped[row["warm"]].append(row)
        result["refinement_curve"] = {str(warm): {"inputs": len(part), "verified_complete": sum(bool(row.get("complete") and row.get("calendar_verified")) for row in part), "all_attempt_cpu_seconds": sum(row["process_profile"]["user_seconds"] + row["process_profile"]["system_seconds"] for row in part), "max_rss_kib": max(row["process_profile"]["max_rss_kib"] for row in part), "process_seconds": describe([row["process_seconds"] for row in part]), "rows": [{k: row.get(k) for k in ["team", "complete", "calendar_verified", "hire_bill", "cash", "failure", "process_seconds", "verification_seconds", "output"]} for row in part]} for warm, part in grouped.items()}
    if (EXP / "runs/final_deeper_points_001/SUMMARY.json").exists():
        points = read("runs/final_deeper_points_001/SUMMARY.json")
        courses = read("runs/final_deeper_course_001/SUMMARY.json")
        result["deeper_postfreeze_diagnostic"] = {"scope": "larger-query diagnosis; does not revise the frozen method",
            "point_queries": {kind: {"queries": sum(row["kind"] == kind for row in points), "feasible": sum(row["kind"] == kind and row["result"]["status"] == "feasible" for row in points)} for kind in ["candidate", "control"]},
            "courses": [{key: row.get(key) for key in ["method", "complete", "calendar_verified", "hire_bill", "cash", "queries", "process_seconds"]} for row in courses]}
    if (EXP / "artifacts/CLEAN_BUILD_CHECK.json").exists():
        checked = read("artifacts/CLEAN_BUILD_CHECK.json")
        result["source_handoff"] = {"archive": "artifacts/placement_component_source.tar.gz", "archive_sha256": checked["archive_sha256"], "build_from_archive": checked["build_from_archive"], "all_packaged_files_unchanged": checked["all_packaged_files_unchanged"], "example_complete": checked["example_summary"]["complete"], "independent_calendar": checked["independent_calendar"], "zero_budget_keeps_incumbent": checked["zero_budget_result"]["cash"] == checked["example_summary"]["cash"], "five_second_input_reverified": checked["five_second_result"]["input_reverified"]}
    result["source_sha256"] = SOURCES
    (EXP / "RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"bounded": {name: panel["wins_ties_losses"] for name, panel in result["bounded"].items()}, "frozen_final_coverage": {key: value for key, value in result["frozen_final_coverage"].items() if key != "rows"}, "cache": result["cache"], "packed_bank": result["packed_bank"]}, indent=2))


if __name__ == "__main__":
    main()
