"""Certify three constrained proposals per course and a refined source control."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/constrained_certificates_001"


def main():
    panel = json.loads((EXP / "runs/constrained_search_001/SUMMARY.json").read_text())
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    banks = [folder for folder in sorted((EXP / "runs/swap_certificates_001").iterdir())
             if folder.is_dir() and (folder / "SUMMARY.json").exists() and json.loads((folder / "SUMMARY.json").read_text())["complete"]]
    banks += [EXP / row["output"] for row in json.loads((EXP / "runs/transfer_controls_001/SUMMARY.json").read_text())]
    OUTPUT.mkdir(exist_ok=False)
    names = ["transfer_certificates", "certify_course", "replay_course"]
    for name in names:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    tasks = []
    for case in panel:
        folder = EXP / case["output"]
        rows = list(csv.DictReader((folder / "candidates.csv").open()))
        best_static = min((row for row in rows if row["method"] != "source" and not row["method"].startswith("dated_")), key=lambda row: float(row["predicted_cost"]))
        best_dated = min((row for row in rows if row["method"] in ["dated_same_quadrant", "dated_owned_cross_quadrant"]), key=lambda row: float(row["predicted_cost"]))
        methods = ["source", "dated_equal_radius", best_static["method"], best_dated["method"]]
        for method in methods:
            tasks.append({**case, "method": method, "layout": str((folder / f"{method}.timeline.txt").relative_to(EXP))})
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "banks": [str(path.relative_to(EXP)) for path in banks],
        "workers": 4, "day_seconds": 9, "query_seconds": 3,
        "control": "source receives the same per-day refinement budget on all 30 days; candidates refine all days too",
        "selection": "three proposals chosen by predefined families and estimated cost; estimated results are not certificates",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in names}}, indent=2) + "\n")

    def run(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}_{case['method']}"
        warm = folder.with_name(folder.name + "_warm")
        with folder.with_suffix(".log").open("w") as stream:
            transferred = subprocess.run([str(OUTPUT / "transfer_certificates"), str(EXP / case["course"]), str(EXP / case["layout"]), str(warm),
                                          *map(str, banks)], stdout=stream, stderr=subprocess.STDOUT)
            if transferred.returncode:
                row = {**case, "error": "transfer failed", "returncode": transferred.returncode}
                print(json.dumps(row), flush=True)
                return row
            completed = subprocess.run([str(OUTPUT / "certify_course"), str(EXP / case["course"]), str(EXP / case["layout"]), str(folder),
                                        "9", "3", str(warm), str((1 << 30) - 1)], stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "returncode": completed.returncode, "output": str(folder.relative_to(EXP)), "transfer": json.loads((warm / "SUMMARY.json").read_text())}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        if row.get("complete"):
            for mode in ["native", "fixed_shops"]:
                report = folder / f"REPLAY_{mode}.json"
                with (folder / f"replay_{mode}.log").open("w") as stream:
                    replay = subprocess.run([str(OUTPUT / "replay_course"), str(EXP / traces[case["episode"]]), str(case["seat"]), str(folder),
                        str(EXP / case["layout"]), str(report), mode], stdout=stream, stderr=subprocess.STDOUT)
                row[f"replay_{mode}"] = json.loads(report.read_text()) if report.exists() else {"returncode": replay.returncode}
            row["full_engine_verified"] = all(row[f"replay_{mode}"].get("valid", False) for mode in ["native", "fixed_shops"])
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
