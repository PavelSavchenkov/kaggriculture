"""Descriptive cross-game tile-role agreement, separate from within-game roles."""
import hashlib
import itertools
import json
from collections import defaultdict
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    sources = ["research/source_profiles/profiles.json", "research/validation_source_profiles/profiles.json", "research/final_source_profiles/PROFILES.json"]
    groups = defaultdict(list)
    for source in sources:
        for row in json.loads((EXP / source).read_text()):
            groups[row["team_id"]].append(row)
    teams = []
    for team_id, rows in sorted(groups.items()):
        comparisons = []
        for a, b in itertools.combinations(rows, 2):
            active, occupied_both, species_equal, coarse_equal, species_both, coarse_both = 0, 0, 0, 0, 0, 0
            for day in range(30):
                for x, y in zip(a["daily_roles"][day], b["daily_roles"][day]):
                    if x is None and y is None:
                        continue
                    active += 1
                    same_species = x == y
                    same_coarse = bool(x and y and x.split("_")[0] == y.split("_")[0])
                    species_equal += same_species
                    coarse_equal += same_coarse
                    if x and y:
                        occupied_both += 1
                        species_both += same_species
                        coarse_both += same_coarse
            comparisons.append({"a": [a["episode"], a["seat"]], "b": [b["episode"], b["seat"]], "active_union": active, "occupied_both": occupied_both,
                "same_species": species_equal, "same_coarse_role": coarse_equal, "same_species_both": species_both, "same_coarse_both": coarse_both})
        active = sum(row["active_union"] for row in comparisons)
        both = sum(row["occupied_both"] for row in comparisons)
        teams.append({"team_id": team_id, "name": rows[0]["team"], "courses": len(rows), "pairs": len(comparisons),
            "species_agreement_active_union": sum(row["same_species"] for row in comparisons) / active,
            "crop_animal_agreement_active_union": sum(row["same_coarse_role"] for row in comparisons) / active,
            "species_agreement_both_occupied": sum(row["same_species_both"] for row in comparisons) / both,
            "crop_animal_agreement_both_occupied": sum(row["same_coarse_both"] for row in comparisons) / both,
            "identical_daily_role_calendars": len({json.dumps(row["daily_roles"]) for row in rows}) == 1,
            "comparisons": comparisons})
    result = {"definition": "Compare the same day/cell in each pair of a team own courses. Active-union excludes both-empty cells but counts occupancy differences as disagreement. Both-occupied conditions on both having a crop or animal. This is descriptive; pairs are dependent and cannot identify online policy logic.",
        "source_sha256": {source: hashlib.sha256((EXP / source).read_bytes()).hexdigest() for source in sources}, "teams": teams}
    (EXP / "research/cross_game_roles_001.json").write_text(json.dumps(result, indent=2) + "\n")
    for row in teams:
        print(json.dumps({key: value for key, value in row.items() if key != "comparisons"}))


if __name__ == "__main__":
    main()
