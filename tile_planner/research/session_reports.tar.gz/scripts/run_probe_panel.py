"""Choose one supported chronological source per team before swap outcomes."""
import csv
import argparse
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
ROUND = ""


def run(case):
    course_id = f"{case['episode']}_{case['seat']}"
    output = EXP / "runs" / ROUND / course_id
    log = output.with_suffix(".log")
    with log.open("w") as stream:
        subprocess.run([str(EXP / "build/probe_swaps"), str(EXP / case["course"]), str(output)], stdout=stream, stderr=subprocess.STDOUT, check=True)
    rows = list(csv.DictReader((output / "swaps.csv").open()))
    improving = [row for row in rows if float(row["delta"]) < 0]
    top = sorted(rows, key=lambda row: float(row["delta"]))[:5]
    retained = sorted(improving, key=lambda row: (-int(row["retained_days"]) - int(row.get("rerouted_days", 0)), float(row["delta"])))[:5]
    result = {**case, "output": str(output.relative_to(EXP)), "probes": len(rows), "predicted_improving": len(improving),
              "top_predicted": top, "top_retained_improving": retained}
    print(json.dumps(result), flush=True)
    return result


def main():
    global ROUND
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", default="swap_probes_002")
    args = parser.parse_args()
    ROUND = args.round
    cases = json.loads((EXP / "runs/source_courses/MANIFEST.json").read_text())["courses"]
    panel = {}
    for case in sorted(cases, key=lambda row: (row["episode"], row["seat"])):
        if case.get("valid_day_contracts") == 30:
            panel.setdefault(case["team"], case)
    output = EXP / "runs" / ROUND
    output.mkdir(exist_ok=False)
    (output / "PANEL.json").write_text(json.dumps({"selection": "earliest fully supported course per development team, before swap results", "cases": list(panel.values()),
        "binary_sha256": hashlib.sha256((EXP / "build/probe_swaps").read_bytes()).hexdigest()}, indent=2) + "\n")
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(run, panel.values()))
    (output / "SUMMARY.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
