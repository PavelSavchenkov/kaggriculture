"""Fresh native continuations and shared-shop demand variation for fixed probes."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/probe_live_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    originals = json.loads((EXP / "runs/probe_courses_001/SUMMARY.json").read_text())
    bank = (EXP / "runs/cold_bank_001.txt").read_text().splitlines()
    bank += [str(EXP / "runs/probe_courses_001" / row["id"]) for row in originals if row["complete"]]
    (OUTPUT / "BANK.txt").write_text("\n".join(bank) + "\n")
    tasks = [{"id": row["id"], "seed": seed, "seat": seat, "finance": "dawn", "shop_seed": None, "world": "native"}
        for row in originals for seed in [1013, 2017] for seat in [0, 1]]
    shop_seeds = [7001, 7013, 7027, 7043, 7057, 7079, 7103, 7121, 7151, 7177, 7207, 7237, 7247, 7297, 7331, 7351]
    tasks += [{"id": id_, "seed": 4001, "seat": 0, "finance": finance, "shop_seed": shop_seed, "world": "shared"}
        for id_ in ["0", "1950", "2717", "2759", "3125"] for shop_seed in shop_seeds for finance in ["dawn", "immediate_goods"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "day_seconds": 6, "query_seconds": 2,
        "refine": "missing days only", "weed_chance": 0.005, "opponent": "live public_router",
        "bank": "frozen original cold courses plus the seven complete development intervention courses; identical for all tasks",
        "scope": "functional robustness and variation of intervention effects; same composition family, not independent placement generalization",
        "conditional_features": "only shops revealed by day 4 for swap 2717 and day 10 for swap 2759; future scenario is evaluator-only",
        "conditional_split": "first eight listed shop seeds are discovery; remaining eight reserved for testing a frozen small rule",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]}}, indent=2) + "\n")

    def run(task):
        name = f"{task['world']}_{task['id']}_{task['seed']}_{task['seat']}_{task['finance']}_{task['shop_seed']}"
        folder = OUTPUT / name
        source = EXP / "runs/life_probes_001" / task["id"]
        scenario = [] if task["shop_seed"] is None else ["--shop_seed", str(task["shop_seed"])]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"),
                str(source / "INPUT.plan"), str(folder), str(source / "assignment.txt"), "6", "2", str(task["seed"]), "0.005",
                "--opponent", "public_router", "--seat", str(task["seat"]), "--finance", task["finance"], "--bank", str(OUTPUT / "BANK.txt"),
                "--refine", "0", *scenario], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), str(task["seed"]), "0.005", str(task["seat"]),
                    str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        # Do not inspect reserved shared-shop outcomes before freezing a rule.
        print(json.dumps({"output": name, "returncode": result.returncode, "calendar_verified": row.get("calendar_verified", False)}), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
