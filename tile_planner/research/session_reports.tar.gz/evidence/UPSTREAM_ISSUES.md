# Issues found at component boundaries

## Replay encoder missing item argument

`fast_game_engine.export_trace.enc_unit(["PLACE"])` returns operation PLACE with item 0 (WHEAT). The official Python engine returns without acting when PLACE has no item. PICKUP and PLANT also require an item. The C++ engine already supports an invalid item value of 255 and handles it correctly.

The first frozen final import of cooked episode 107375112, seat 1, fails full-state parity at step 94. The opposing player's raw action includes bare PLACE; cooked's corresponding action explicitly names WHEAT. The trace encoder turned both into PLACE WHEAT. The local converter in this experiment now supplies invalid item 255 for these missing/non-string arguments. Original v1 traces are preserved; corrected traces are under `research/final_placement_traces_v2/`. The persistent root encoder was not edited.

## Net physical trades omit ordered stock requirements

The current persistent extractor cancels same-hour product sales and purchases in its physical contract. This preserves net stock, but can lose the stock required before a later buyback. For example, SELL FERTILIZER 2 followed by BUY_PRODUCT FERTILIZER 1 requires two starting units, not one.

The experiment's fixed-finance adapter restores the maximum sell-minus-buy prefix for the hour and matching canceled purchases. No worker acts between order slots, so this exactly restores the required starting stock and unchanged final stock for accepted product trades. It does not establish cash, market availability or capacity feasibility. Full engine validation remains required. Earlier complete full-game results remain valid; physical-only results need the stronger contract or a full check.

## Lifetime input format limits

Versions one through three represent one occurrence of each service operation per life/day. The frozen final method rejects two Blurry/Unknown Mother-Goose courses with repeated same-day fertilization. The separate version-four extension explicitly preserves repeats, including input consumption, and imports both exactly. Those original failures remain in the frozen coverage count. One development Mengfei course still has unsupported within-day overripe decay before harvest. An intraday event/time-window contract should preserve it explicitly; increasing harvest output would change the supplied plan.

## Recorded opponent no-op versus own certificate validation

The shared strict action reader rejects an invalid item encoding even when the file belongs to a recorded opponent. This prevented the independent calendar check on corrected cooked episode 107375112 despite complete engine execution. The experiment now uses a bounded recorded-opponent reader, preserves the original rival command in the engine, and normalizes only proven invalid-item no-ops for the financial projection. Own action files retain strict validation. The separately saved corrected calendar verifies all 719 transitions; the original frozen verifier failure is preserved.

## Earlier overflow can break later fixed sales

A physically cheaper schedule can leave less stock for a later fixed sale. A Terry continuation reaches day 29 two carrots short after 29 valid days. The original driver throws an endpoint validation error without writing a summary. The current adapter reports the first resource deficit as an incomplete course instead. This is a status improvement, not a repair or new certificate. `runs/resource_shortfall_check_001/CHECK.json` reproduces the case using its saved prefix with zero solver queries.
