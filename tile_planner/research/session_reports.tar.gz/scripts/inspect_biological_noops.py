"""Use the official unit transition to identify replay biological no-ops."""
import copy
import hashlib
import inspect
import json
from collections import Counter
from pathlib import Path

from kaggle_environments.envs.kaggriculture import kaggriculture as game

EXP = Path(__file__).resolve().parents[1]
BIO = {"WATER", "FEED", "CARE", "COLLECT_FERTILIZER", "HARVEST", "FERTILIZE"}


def main():
    if hashlib.sha256(inspect.getsource(game).encode()).hexdigest() != "bc8a54879ef02c7ea64b8b333d6a976f0ea65c4949149d01f463f23bccee653e":
        raise ValueError("official engine source differs")
    directory = EXP / "replays/final_placement/team_16730612"
    rows = []
    for path in sorted(directory.glob("episode-*-replay.json")):
        replay = json.loads(path.read_text())
        seat = replay["info"]["TeamNames"].index("Unknown Mother-Goose")
        noops = []; counts = Counter(); changes = Counter()
        for step, (before, after) in enumerate(zip(replay["steps"], replay["steps"][1:])):
            obs = before[seat]["observation"]
            farm = copy.deepcopy(obs["farms"][seat]); private = copy.deepcopy(obs["private"])
            action = after[seat]["action"] or {}
            units = [action.get("farmer") or ["PASS"], *(action.get("hands") or [])]
            for actor, unit in enumerate(units[:1 + len(farm["hands"])]):
                previous_farm = copy.deepcopy(farm); previous_private = copy.deepcopy(private)
                game._apply_unit_action(farm, private, actor, unit, 10, obs["day"], 24, 100)
                if unit and unit[0] in BIO:
                    counts[unit[0]] += 1
                    if farm == previous_farm and private == previous_private:
                        pos = previous_farm["farmer"] if actor == 0 else previous_farm["hands"][actor - 1]
                        noops.append({"step": step, "day": obs["day"], "hour": obs["hour"], "actor": actor, "cell": pos[1] * 10 + pos[0], "operation": unit[0]})
                    else:
                        changes[unit[0]] += 1
        rows.append({"episode": replay["info"]["EpisodeId"], "seat": seat, "counts": dict(counts), "state_changing": dict(changes),
            "noops_by_operation": dict(Counter(row["operation"] for row in noops)), "noops": noops})
    output = EXP / "research/biological_noops_001.json"
    output.write_text(json.dumps({"source": "official unit transition only; sequential actors; no policy or timing changed", "cases": rows}, indent=2) + "\n")
    print(json.dumps([{k: v for k, v in row.items() if k != "noops"} for row in rows], indent=2))


if __name__ == "__main__":
    main()
