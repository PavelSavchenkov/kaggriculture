"""Give original layouts the same per-day budgets used to fill swap-bank gaps."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/transfer_controls_001"


def main():
    rows = json.loads((EXP / "runs/transfer_panel_001/SUMMARY.json").read_text())
    originals = [row for row in rows if row["method"] == "source"]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    tasks = []
    for row in originals:
        warm = EXP / "runs/transfer_panel_001" / f"{row['episode']}_{row['seat']}_swap_warm"
        days = list(csv.DictReader((warm / "days.csv").open()))
        mask = sum(1 << int(day["day"]) for day in days if day["certified"] == "0")
        tasks.append({**row, "refine_mask": mask})
    OUTPUT.mkdir(exist_ok=False)
    for name in ["certify_course", "replay_course"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    layout = EXP / "runs/swap_probes_002/107269880_1/source.layout.txt"
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": [{"episode": row["episode"], "seat": row["seat"], "refine_mask": row["refine_mask"]} for row in tasks],
        "rule": "Same nine-second day budget and three-second queries on every day that needed new solving for the swapped placement; all original-layout bank witnesses retained.",
        "workers": 2, "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["certify_course", "replay_course"]}}, indent=2) + "\n")
    def run(task):
        folder = OUTPUT / f"{task['episode']}_{task['seat']}"
        with folder.with_suffix(".log").open("w") as stream:
            completed = subprocess.run([str(OUTPUT / "certify_course"), str(EXP / task["course"]), str(layout), str(folder), "9", "3",
                str(EXP / task["output"]), str(task["refine_mask"])], stdout=stream, stderr=subprocess.STDOUT)
        result = {"episode": task["episode"], "seat": task["seat"], "team": task["team"], "refine_mask": task["refine_mask"], "returncode": completed.returncode,
                  "output": str(folder.relative_to(EXP)), "bank_bill": task["certified_partial_bill"]}
        if (folder / "SUMMARY.json").exists():
            result.update(json.loads((folder / "SUMMARY.json").read_text()))
        if result.get("complete"):
            report = folder / "REPLAY_native.json"
            with (folder / "replay_native.log").open("w") as stream:
                subprocess.run([str(OUTPUT / "replay_course"), str(EXP / traces[task["episode"]]), str(task["seat"]), str(folder), str(layout), str(report), "native"],
                               stdout=stream, stderr=subprocess.STDOUT)
            result["replay_native"] = json.loads(report.read_text())
            result["full_engine_verified"] = result["replay_native"]["valid"]
        (folder / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result), flush=True)
        return result
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
