**Recommendation: optimize tile placement across the remaining season for a fixed dated farm plan.**

Given the current farm, fixed crop/animal lifetimes, required work and economic obligations, choose where future plants and animals go. Use the existing estimator and day solver to find a cheap executable placement. Verify the complete continuation. Existing plants and placed animals stay where they are.

This is my preferred next isolated optimization task after the day solver, fast day estimator and sales planner. It is a judgment about usefulness, separation and plausible headroom, not a demonstrated ranking of future game-score gains. Begin with a bounded headroom study before committing to a long optimization session.

I read all 18 pages of the only root PDF, agent_development_strategy_sep08.pdf, and visually checked its task definitions and evidence tables on pages 7-10 and 14-16. I also read the sealed experiment's final reports, relevant positive and negative studies, and implementation code, then checked the newer estimator and sales-planner boundaries. The sealed experiment and existing components were not modified. The small accompanying script only reanalyzes saved results.

**Why this fits the three requirements**

The objective can be concrete: minimize the actual remaining-season hire bill for the same required work, production, input availability, delivery deadlines and terminal resources, within a fixed CPU budget. Every accepted placement must have a verified complete schedule. Distance and predicted labor are search aids; they are not the objective.

The module is useful whenever the outer search changes species, counts, start dates, crop rotations or available land. It also lets cold construction choose a layout instead of inheriting one. A better day solver cannot change an already fixed tile assignment. A better labor estimator can identify an expensive assignment but cannot create its replacement. The sales planner explicitly takes a supplied resource calendar and leaves tiles and routes outside its interface. See [sales-planner contract](/home/pavel/Programming/kaggriculture/experiments/v6/sep09_sales_planner/DESIGN.md:9).

There is a weak enough existing placement baseline to justify investigation. The early general estimator assigns lives greedily using quadrant, shed distance and a small animal-structure preference. It does not optimize complete daily routes or seasonal worker thresholds. See [estimate.hpp](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/include/estimate.hpp:39). The later large-expansion generator sorts southeast-quadrant cells by x+y and takes the first requested number. Its seven larger crop/animal cases therefore start from a fixed nearest-cell rule. See [run.py](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/expansion_portfolio_sep08_001/next_compile/run.py:17).

The newer estimator improves a different part of this process. Its layout corpus contains five variants per day: original, near, far and two shuffles. Those variants move starting tile states and their work inside each ownership quadrant. They do not construct a legal sequence of placements through a season. See [layout generation](/home/pavel/Programming/kaggriculture/fast_day_solver_estimator/development/scripts/make_layout_pools.py:28). Its accepted result makes choosing among supplied layouts cheaper; it does not establish that the supplied choices are sufficient.

The full-season requirement matters. Two plants visited on the same days may share worker trips; two equally distant plants visited on different days may not. A position can be convenient today but unavailable when the next crop needs it. A small route difference can cross an expensive hiring threshold. Existing animals cannot be moved, and crops cannot change tiles between days. Independent daily permutations miss these constraints.

**What the evidence supports, and what it does not**

- The archived owned-land-first test improved a weak mixed farm by delaying a $1,000 land purchase and allowing its two sheep to appear on day 0 instead of day 8. Against public_router, mean own cash increased about $1,660. Walking increased. This demonstrates a placement/funding interaction, not a clean labor-only gain or a strong-agent result. See [placement results](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/compiler_placement_sep08_001/RESULTS.md).
- A later productive-wheat search found no improvement among six single-cell choices and two adjacent pairs. Two different placements tied the incumbent economically. Other choices lost money; an additive visit penalty wrongly preferred the pairs. Retain this as a negative control. See [wheat placement study](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/productive_wheat_placements_001/README.md).
- My read-only reanalysis of the estimator's 46 saved one-day pools finds a lower best-known workforce in 11 pools when choosing retrospectively among all five layouts instead of the original. Mean hire-bill difference is $70.74, median zero; excluding the largest difference reduces the mean to $16.87. Against the near variant, 19 of 44 certified cases have a cheaper alternative. Two near cases are unresolved. See [calculation and per-case data](/home/pavel/Programming/kaggriculture/work/sep10_next_separable_task/layout_evidence.json).
- These are certified upper bills found under bounded searches, not proven minimum labor. Search difficulty contributes to differences. The artificial day layouts are not executable edits to an existing live farm. The alternatives already belong to the estimator benchmark. Their savings are not new gains beyond that estimator, cannot be added across unrelated days, and do not establish season or league improvement.
- The archived $3,804 wheat saving came from worker scheduling with unchanged layout and timed trades. It supports optimizing realized labor, but must not be presented as placement headroom. See [session summary](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/final/SESSION_SUMMARY.md).

The remaining opportunity is to generate better, consistent placements for complete plans, and to show they improve on spending the same compute on the original placement.

**Proposed task contract**

Input:

- A start state and explicit planning period. Start at dawn initially, matching the current estimator's supported scope.
- Named crop/animal lifetimes, their fixed dates, and required service/harvest work with allowed times. Include crop clearing and animal structures explicitly.
- Existing entities fixed to their actual tiles; allowed tiles for each future life; land availability dates; occupancy and replacement constraints.
- Input-release and output-delivery obligations, financial assumptions, permitted hiring times/order slots, and required continuation resources and worker endpoints.
- An optional certified incumbent, reusable day schedules and a total CPU budget.

Output: a tile assignment for every future life, resulting day contracts, best verified complete schedule found, actual hire cost, resource calendar, and status. Return an explicit unresolved result when no schedule is found. Keep the incumbent whenever it remains valid. An unsuccessful solver call does not prove the placement infeasible.

For the first benchmark, keep nonlabor transactions and their successful quantities/slots fixed. Preserve the corresponding resource deadlines and verify affordability and capacity in the full engine. This deliberately isolates placement and hiring from financial-policy research. A later integration should pass each schedule's actual resource calendar to the same frozen sales planner and compare final cash/margin under matched scenarios. The initial restricted result must not be described as optimal joint placement and sales.

The optimizer owns tile assignments and which assignments to investigate. Workforce queries and route construction use frozen existing components. It does not change species, lifetime dates, service requirements, opponent forecasting or branch policy. Those decisions can later supply different inputs to the same module.

Occupancy must follow real event order, including same-day harvest/clearing/replanting. A layout cannot obtain a benefit by moving an existing animal, dropping inconvenient work, changing the required output, or relying on an extra action after turn 718. The full-game checker must cover cash and the 100-item shed because the physical day solver does not certify those.

**Benchmark and first decision**

Use complete remaining-season contracts from several distinct crop, animal and mixed families. Include strong inherited farms, new-land additions, replacements on existing land, and construction from an empty starting layout. Keep all descendants of one source family together. Preserve the failed wheat-placement study as a control; reserve unfamiliar families for the final test.

Compare these methods with identical work, financial assumptions and total compute:

1. Preserve the original placement and spend the budget improving its worker schedules.
2. Use the current greedy placement and current estimator-guided ordering.
3. Search legal placement changes using the same estimator, workforce-query policy and day solver.

For an initial headroom study, try relocations of future lives, legal swaps, and small groups of assignments changed together. Preserve each life's location until it ends, and recompute every affected day. Use the estimator for screening, exact compilation for finalists, and full continuation replay for acceptance. Cache identical day contracts and retain certificates. Recompile changed dependencies rather than pretending their original endpoints still hold.

Primary measurements are the best verified season hire bill reached at each CPU budget and complete-plan coverage. Report both separately; unknown cases must not disappear from the denominator. Also report time to the first complete schedule, cost regret against stronger best-known references, per-family gains, and losses relative to a valid incumbent. Tiny cases may have proven optima if supported by exhaustive certificates; otherwise call the reference best-known.

The first go/no-go decision is whether changing placement produces meaningful certified savings or additional complete plans beyond equal-budget fixed-placement search across several useful families. If it only improves deliberately poor layouts, repeats routing gains, or ties the strong controls, do not expand the session merely because geometry is interesting. If generalizing the contract adapter is the dominant obstacle, prioritize that compiler work before further placement search.

The complete-course adapter is real required work. The current expansion compiler is tied to a source course, southeast-quadrant additions and specific service calendars; a generic adapter is not already available. Start with its supported complete courses to establish headroom, then widen the input contract. Its limitations are documented in the [compiler README](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/submission_losses_sep08_001/general_quadrant_compile/README.md).

Finally, test resulting courses with the same sales planner and live opponents on matched scenarios. Fixed-scenario labor savings alone do not establish a stronger policy: hire counts are public, opponents may react, and changed field occupancy can affect native randomness.

**Why I rank the other candidates lower for this particular request**

| Candidate | Assessment |
| --- | --- |
| General multi-day compiler | The closest alternative and probably the largest overall engineering bottleneck. But an unrestricted task includes placement, service, funding, endpoint choice, cache correctness and repair. Much of its historical funding/labor work is now assigned to the three existing components. Extracting placement gives a narrower optimization objective. The required compiler adapter still belongs in the delivery. |
| Service and harvest-calendar optimizer | A strong next candidate. Exact crop service deletion and a few animal-care removals exist; coordinated changes across days could do better. Its objective must price actual labor and changed inputs/output, not action count. Current evidence gives less reason to rank it above placement across unfamiliar farms, although this ordering should change if placement headroom is weak. |
| Public rival-flow forecaster | Broadly useful to composition valuation and the sales planner. The existing model omits future planting and expansion. However, much of the large reported oracle gain involved unavailable future shops; that is not all learnable error. Evaluate calibrated forecasts and decision regret on unseen opponent families. More accurate crop totals previously gave almost no benefit in an already exhausted two-choice library. |
| Marginal scorer or branch selector | Benefits from the three current components, but refining selection over weak alternatives can have little value. The archived wheat/tomato library had only $4.60 mean hindsight headroom on its tested panel. New complete alternatives are a more promising target first. |
| Exact biology, evaluator or deployment tooling | Clear contracts and broad reuse. Existing implementations already have substantial correctness/operational evidence. I found less evidence that an isolated additional push here is the best next use of effort. |
| General proposal search or arbitrary runtime repair | Important, but each leaves too many coupled decisions open for the focused optimization session requested. |

The PDF's emphasis on multi-day compilation remains valid. This recommendation extracts its fixed-plan spatial decision, uses the three existing projects as dependencies, and makes any claimed gain answerable to a complete-season benchmark.

Additional evidence: [forecast oracle ablation](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/atakan_oracle_ablation_001/README.md), [crop-selector headroom](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/runs/crop_choice_estimator_001/README.md), [existing crop-service search](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/include/crop_service.hpp), [estimator results and limits](/home/pavel/Programming/kaggriculture/fast_day_solver_estimator/docs/RESULTS.md), [archived task contracts](/home/pavel/Programming/kaggriculture/experiments/v6/sep07_compositions_v0/final/NEXT_EXPERIMENT.md).
