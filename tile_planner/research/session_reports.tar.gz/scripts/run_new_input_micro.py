"""Prespecified 0.1-second refinement of reused schedules on the new inputs."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
INPUT = EXP / "runs/new_inputs_001"
OUTPUT = EXP / "runs/new_input_micro_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/cold_bank_001.txt", OUTPUT / "BANK.txt")
    names = [row["name"] for row in csv.DictReader((INPUT / "cases.csv").open())]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": names, "workers": 4, "missing_day_seconds": 6,
        "query_seconds": 2, "warm_day_seconds": 0.1, "seed": 4001, "shop_seed": 5003, "weed_chance": 0.005,
        "scope": "development follow-up; same inputs and frozen bank as new_input_panel_001; changed bank fallback now tries stripped weed work even if exact group fails",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]}}, indent=2) + "\n")

    def run(name):
        folder = OUTPUT / name
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"),
                str(INPUT / (name + ".plan")), str(folder), "animals", "6", "2", "4001", "0.005", "--opponent", "public_router",
                "--shop_seed", "5003", "--bank", str(OUTPUT / "BANK.txt"), "--warm_seconds", "0.1"], stdout=stream, stderr=subprocess.STDOUT)
        row = {"case": name, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), "4001", "0.005", "0", str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, names))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
