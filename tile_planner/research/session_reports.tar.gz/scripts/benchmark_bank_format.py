"""Paired end-to-end compilation with text versus packed identical banks."""
import hashlib
import json
import random
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/bank_format_benchmark_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/compile_cold", OUTPUT / "compile_cold")
    cases = ["wheat12", "dairy", "mixed_animals", "geese", "crop_rotation", "expanding_mixed"]
    tasks = [{"case": case, "format": format_, "repeat": repeat} for case in cases for repeat in range(3) for format_ in ["txt", "bin"]]
    random.Random(6011).shuffle(tasks)
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "solver_budget": 0,
        "seed": 1009, "weed_chance": 0, "shop_seed": 3001, "opponent": "live public_router",
        "binary_sha256": hashlib.sha256((OUTPUT / "compile_cold").read_bytes()).hexdigest(),
        "comparison": "identical bank contents; exact lookup parity already checked on 390 days; include loading, compile, full execution and artifact writing"}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['case']}_{task['format']}_{task['repeat']}"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"),
                task["case"], str(folder), "animals" if task["case"] == "expanding_mixed" else "nearest", "0", "0", "1009", "0",
                "--bank", str(EXP / ("runs/cold_bank_001." + task["format"])), "--refine", "0", "--opponent", "public_router", "--shop_seed", "3001"],
                stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-1000:]
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
