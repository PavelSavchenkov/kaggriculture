"""Static quality/time figure for the development refinement curve."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter

EXP = Path(__file__).resolve().parents[1]


def main():
    rows = json.loads((EXP / "runs/refinement_curve_001/SUMMARY.json").read_text())
    teams = ["SpaTaro", "Otter Vibe", "DeeperNet", "mtmr_s1", "Mengfei Li", "binghua"]
    figure, axes = plt.subplots(2, 3, figsize=(13.5, 8.5))
    for ax, team in zip(axes.flat, teams):
        group = sorted([row for row in rows if row["team"] == team], key=lambda row: row["warm"])
        valid = [row for row in group if row.get("complete") and row.get("calendar_verified")]
        if valid:
            ax.plot([row["process_seconds"] for row in valid], [row["hire_bill"] for row in valid], color="#23688c", marker="o", linewidth=1.4)
            bills = [row["hire_bill"] for row in valid]
            span = max(max(bills) - min(bills), max(bills) * 0.05)
            ax.set_ylim(min(bills) - span * 0.26, max(bills) + span * 0.30)
            for index, row in enumerate(valid):
                ax.annotate(str(row["warm"]), (row["process_seconds"], row["hire_bill"]), xytext=(4, 9 if index % 2 == 0 else -15), textcoords="offset points", fontsize=9)
            ax.set_ylabel("Complete season hire bill")
        else:
            ax.set_ylim(0, 1)
            ax.set_yticks([])
            ax.text(0.5, 0.58, "No complete course\nat any tested cap", transform=ax.transAxes, ha="center", color="#8b3434", fontsize=11)
        for index, row in enumerate(group):
            if row in valid:
                continue
            ax.plot(row["process_seconds"], 0.08, marker="x", markersize=8, color="#a53939", transform=ax.get_xaxis_transform())
            offset = 10 + 15 * (index % 3) if not valid else 10
            ax.annotate(str(row["warm"]), (row["process_seconds"], 0.08), xycoords=ax.get_xaxis_transform(), xytext=(3, offset), textcoords="offset points", fontsize=9, color="#a53939", arrowprops={"arrowstyle": "-", "color": "#a53939", "linewidth": 0.5} if not valid else None)
        ax.set_xscale("log")
        ax.set_xlim(0.06, 370)
        ax.set_xticks([0.1, 1, 10, 100])
        ax.xaxis.set_major_formatter(ScalarFormatter())
        ax.set_xlabel("Compile process seconds (log scale)")
        ax.set_title(team, loc="left", weight="bold")
        ax.grid(alpha=0.18)
        ax.spines[["top", "right"]].set_visible(False)
    figure.suptitle("More refinement improves some plans much more than others", fontsize=17, x=0.065, ha="left", y=0.99)
    figure.text(0.065, 0.945, "Labels: seconds allowed per reused day. Blue: complete and independently verified. Red ×: incomplete; no bill plotted.", fontsize=10)
    figure.text(0.065, 0.018, "Six development plans • same assignment, bank, finance and recorded opponent • one run per cap • missing-day cap remains 9 seconds", fontsize=10)
    figure.subplots_adjust(left=0.065, right=0.985, top=0.885, bottom=0.105, wspace=0.31, hspace=0.44)
    output = EXP / "research/refinement_curve_001"
    output.mkdir(exist_ok=True)
    figure.savefig(output / "quality_time.png", dpi=170)
    figure.savefig(output / "quality_time.svg")
    plt.close(figure)


if __name__ == "__main__":
    main()
