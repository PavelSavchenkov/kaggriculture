"""Fault and untouched-control panel over all development source courses."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def run(case, output):
    folder = output / f"{case['episode']}_{case['seat']}"
    with folder.with_suffix(".log").open("w") as stream:
        result = subprocess.run([str(output / "benchmark_repairs"), str(EXP / case["trace"]), str(case["seat"]),
                                 str(EXP / case["course"]), str(folder), "8"], stdout=stream, stderr=subprocess.STDOUT)
    row = {**case, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
    if (folder / "SUMMARY.json").exists():
        row.update(json.loads((folder / "SUMMARY.json").read_text()))
    (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", default="repair_panel_002")
    args = parser.parse_args()
    output = EXP / "runs" / args.round
    courses = json.loads((EXP / "runs/source_courses/MANIFEST.json").read_text())["courses"]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    cases = [{**case, "trace": traces[case["episode"]]} for case in courses if case.get("source_parity")]
    output.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/benchmark_repairs", output / "benchmark_repairs")
    (output / "PROTOCOL.json").write_text(json.dumps({"cases": cases, "workers": 2, "faults_per_kind": 8,
        "worlds": ["native", "fixed_shops"], "modes": {"0": "none", "1": "worker_queue", "2": "queue_and_pass_absorption", "3": "queue_and_cash_advance", "4": "cash_guard_through_next_day", "5": "cash_guard_through_end", "6": "queue_and_idle_worker_preclear", "7": "full_cash_guard_and_forecast_profit"},
        "guard_forecast": "own current state and plan; no opponent trades, no town demand, no new weeds; all forecast actions/orders must succeed and advanced sales be canceled",
        "binary_sha256": hashlib.sha256((output / "benchmark_repairs").read_bytes()).hexdigest(),
        "cash_fault": "balance two coins below the own-only current purchase funding threshold; removed wealth is reported",
        "weed_fault": "weed at dawn on an empty tile with a same-day planned plant or build; uniformly spaced in chronological eligible events"}, indent=2) + "\n")
    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(lambda case: run(case, output), cases))
    (output / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
