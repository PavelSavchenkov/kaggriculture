"""Post-freeze serialization check on the eight supplied real incumbents."""
import argparse
import hashlib
import json
import random
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/real_bank_format_001"


def main():
    global OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--baseline-compiler", type=Path)
    args = parser.parse_args()
    OUTPUT = args.output.resolve()
    OUTPUT.mkdir(exist_ok=False)
    cases = json.loads((EXP / "runs/final_panel_001/INCUMBENTS.json").read_text())["cases"]
    for name in ["107369606_1/recorded_0.1", "107375473_0/public_router_9"]:
        folder = EXP / "runs/repeated_service_panel_001" / name
        row = json.loads((folder / "SUMMARY.json").read_text())
        cases.append({**row, "episode": int(name.split("_")[0]), "output": str(folder.relative_to(EXP))})
    for name in ["compile_cold", "export_calendar", "pack_bank"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(__file__, OUTPUT / "benchmark_real_bank_format.py")
    if args.baseline_compiler:
        shutil.copy2(args.baseline_compiler, OUTPUT / "baseline_compile_cold")
    for row in cases:
        assert row["complete"]
        name = f"{row['episode']}_{row['seat']}"
        folder = OUTPUT / name
        folder.mkdir()
        source = EXP / row["output"]
        (folder / "BANK.txt").write_text(str(source) + "\n")
        with (folder / "pack.log").open("w") as stream:
            subprocess.run(list(map(str, [OUTPUT / "pack_bank", folder / "BANK.txt", folder / "BANK.bin", folder / "BANK.txt"])), stdout=stream, stderr=subprocess.STDOUT, check=True)
    variants = [("txt", "compile_cold", "txt"), ("bin", "compile_cold", "bin")]
    if args.baseline_compiler:
        variants = [("old_txt", "baseline_compile_cold", "txt"), ("old_bin", "baseline_compile_cold", "bin"), ("new_bin", "compile_cold", "bin")]
    tasks = [{"input": row, "variant": variant, "compiler": compiler, "format": kind, "repeat": repeat} for row in cases for variant, compiler, kind in variants for repeat in range(5 if args.baseline_compiler else 3)]
    random.Random(9117).shuffle(tasks)
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "scope": "post-freeze exact-reuse comparison; identical per-case bank containing only the supplied complete incumbent; no fitted placement or resource rule",
        "settings": "same plan/assignment, actual seed/seat, source financial commitments and opponent; zero new solver time",
        "paired_repeats": 5 if args.baseline_compiler else 3,
        "change": "exact identical-lifetime compilation reuse plus bank format" if args.baseline_compiler else "bank format only",
        "timing": "record compilation and independent calendar processes separately and together; blocking child wait avoids deadline polling overhead on these zero-query courses; exclude bank construction and binary copying",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar", "pack_bank"] + (["baseline_compile_cold"] if args.baseline_compiler else [])}}, indent=2) + "\n")

    def run(task):
        row = task["input"]
        source = EXP / row["output"]
        parent = OUTPUT / f"{row['episode']}_{row['seat']}"
        folder = parent / f"{task['variant']}_{task['repeat']}"
        options = ["--bank", parent / ("BANK." + task["format"]), "--warm_seconds", 0, "--opponent", row["opponent"].removeprefix("live_"), "--seat", row["seat"], "--finance", row["finance"], "--finance_source", row["finance_source"], "--repair_preparation", 1]
        if row.get("opponent_trace"):
            options += ["--opponent_trace", row["opponent_trace"]]
        command = [OUTPUT / task["compiler"], source / "INPUT.plan", folder, source / "assignment.txt", 0, 0, row["seed"], row["weed_chance"], *options]
        began = time.monotonic()
        with (parent / f"{folder.name}.log").open("w") as stream:
            done = subprocess.run(["/usr/bin/time", "-f", "{\"user_seconds\":%U,\"system_seconds\":%S,\"max_rss_kib\":%M,\"wall_seconds\":%e}", "-o", str(parent / f"{folder.name}.time.json"), *map(str, command)], stdout=stream, stderr=subprocess.STDOUT)
        compile_seconds = time.monotonic() - began
        result = {"episode": row["episode"], "seat": row["seat"], "variant": task["variant"], "format": task["format"], "repeat": task["repeat"], "returncode": done.returncode, "output": str(folder.relative_to(EXP)), "measured_compile_seconds": compile_seconds}
        result.update(json.loads((folder / "SUMMARY.json").read_text()))
        result["process_profile"] = json.loads((parent / f"{folder.name}.time.json").read_text().splitlines()[-1])
        if result["complete"]:
            began = time.monotonic()
            with (folder / "calendar.log").open("w") as stream:
                verified = subprocess.run(list(map(str, [OUTPUT / "export_calendar", folder, row["seed"], row["weed_chance"], row["seat"], folder / "calendar"])), stdout=stream, stderr=subprocess.STDOUT)
            result["measured_verification_seconds"] = time.monotonic() - began
            result["calendar_verified"] = verified.returncode == 0
        result["measured_total_seconds"] = result["measured_compile_seconds"] + result.get("measured_verification_seconds", 0)
        result["actions_sha256"] = hashlib.sha256(b"".join((folder / f"{day:02d}/executable.actions.txt").read_bytes() for day in range(result["days"]))).hexdigest()
        (folder / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
        return result

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    control = variants[0][0]
    pairs = {(row["episode"], row["seat"], row["repeat"]): row for row in rows if row["variant"] == control}
    keys = ["complete", "hire_bill", "cash", "opponent_cash", "failure", "actions_sha256", "calendar_verified"]
    identical = all(all(row.get(key) == pairs[row["episode"], row["seat"], row["repeat"]].get(key) for key in keys) for row in rows if row["variant"] != control)
    result = {"rows": rows, "paired_actions_and_outcomes_identical": identical, "all_complete_verified": all(row["complete"] and row.get("calendar_verified") for row in rows)}
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}))
    assert identical


if __name__ == "__main__":
    main()
