"""Same bounded method on the repeated-service coverage extension."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/distinct_bounded_panel_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    tools = OUTPUT / "tools"; tools.mkdir()
    for name in ["probe_lives", "solve_point", "pack_bank", "compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, tools / name)
    launcher = OUTPUT / "optimize_placement.py"; shutil.copy2(EXP / "scripts/optimize_placement.py", launcher)
    inputs = ["107369606_1/recorded_0.1", "107375473_0/public_router_9"]
    tasks = [{"case": name, "mode": mode} for name in inputs for mode in ["fixed", "search"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "seconds": 180, "objective": "cash", "seed": 9013,
        "scope": "post-freeze format extension on the two initially unsupported distinct-family cases; one recorded, one live continuation; no placement rule fitted",
        "selection": "first case has only a recorded complete course; second uses its fully refined live course",
        "launcher_sha256": hashlib.sha256(launcher.read_bytes()).hexdigest(),
        "binary_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in tools.iterdir()}}, indent=2) + "\n")

    def run(task):
        name = task["case"].replace("/", "_") + "_" + task["mode"]
        folder = OUTPUT / name
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["python", str(launcher), str(EXP / "runs/repeated_service_panel_001" / task["case"]), str(folder),
                "--seconds", "180", "--mode", task["mode"], "--objective", "cash", "--seed", "9013", "--tools", str(tools)], stdout=stream, stderr=subprocess.STDOUT, timeout=210)
        row = {**task, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "RESULT.json").exists():
            row.update(json.loads((folder / "RESULT.json").read_text()))
        print(json.dumps({k: v for k, v in row.items() if k != "events"}), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
