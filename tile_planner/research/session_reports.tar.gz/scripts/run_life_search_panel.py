"""Search individual lifetimes in predefined cold compositions."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
CASES = ["wheat12", "dairy", "mixed_animals", "geese", "crop_rotation", "expanding_mixed"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", default="life_search_002")
    args = parser.parse_args()
    output = EXP / "runs" / args.round
    output.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/search_lives", output / "search_lives")
    (output / "PROTOCOL.json").write_text(json.dumps({"cases": CASES, "seconds_per_search": 15, "seed": 65537, "workers": 2,
        "objective": "estimated complete hire bill under fixed biological output and dawn surplus-sale finance baseline",
        "claim_scope": "proposals only; unbounded weed-free stock projection is not complete-game feasibility",
        "binary_sha256": hashlib.sha256((output / "search_lives").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(name):
        folder = output / name
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(output / "search_lives"), name, str(folder), "15", "65537"], stdout=stream, stderr=subprocess.STDOUT)
        row = {"case": name, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, CASES))
    (output / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
