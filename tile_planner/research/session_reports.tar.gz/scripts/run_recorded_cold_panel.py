"""Fixed replay finance and opponent: isolate compilation from changed markets."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/replay_recorded_panel_001"


def main():
    global OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    OUTPUT = args.output.resolve()
    source = json.loads((EXP / "runs/replay_cold_panel_001/PROTOCOL.json").read_text())
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: EXP / game["trace"] for game in games}
    tasks = [task for task in source["tasks"] if task["method"] in ["source_preparation_micro", "source_preparation_refine"]]
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/replay_bank_001.bin", OUTPUT / "BANK.bin")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "comparison": "same real biological commitments and accepted trades, original seed/seat and recorded opponent; micro versus full warm refinement",
        "purpose": "diagnose new-opponent funding failures; recorded continuation is evaluation, never an online information input",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]}}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['episode']}_{task['seat']}_{task['method']}"
        imported = EXP / task["output"]
        warm = 0.1 if task["method"].endswith("micro") else 9
        command = [str(OUTPUT / "compile_cold"), str(imported / "INPUT.plan"), str(folder), str(imported / "assignment.txt"), "9", "3", str(task["seed"]), "0.005",
            "--seat", str(task["seat"]), "--opponent", "recorded", "--opponent_trace", str(traces[task["episode"]]),
            "--finance_source", str(EXP / task["source_course"]), "--bank", str(OUTPUT / "BANK.bin"), "--warm_seconds", str(warm), "--repair_preparation", "1"]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), *command], stdout=stream, stderr=subprocess.STDOUT)
        row = {"team": task["team"], "episode": task["episode"], "seat": task["seat"], "method": task["method"], "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                result = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), str(task["seed"]), "0.005", str(task["seat"]), str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = result.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
