"""Locate repeated operations inside the same source lifetime and day."""
import json
from collections import Counter
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    reports = []
    for name in ["107369606_1", "107375473_0"]:
        folder = EXP / "runs/final_panel_001" / name / "source"
        repeats = []
        for day in range(30):
            problem = json.loads((folder / f"{day:02d}/problem.json").read_text())
            for work in problem["tile_work"]:
                state = problem["start"]["managed_tiles"][work["tile"]]["state"]
                item = state["animal"] if state["animal"] >= 0 else state["crop"]
                seen = set(); sequence = []
                for action in work["actions"]:
                    op = action["op"]
                    if op in ["plant", "place"]:
                        item = action["arg"]; seen = set(); sequence = []
                    if op in ["water", "feed", "care", "collect_fertilizer", "harvest", "fertilize"]:
                        sequence.append(op)
                        if op in seen:
                            repeats.append({"day": day, "cell": work["tile"], "item": item, "op": op, "sequence": list(sequence)})
                        seen.add(op)
                    if op == "dig" or (op == "harvest" and item in [0, 1, 4]):
                        seen = set(); sequence = []
        reports.append({"case": name, "counts": dict(Counter(row["op"] for row in repeats)), "repeats": repeats})
    (EXP / "research/repeated_services_001.json").write_text(json.dumps(reports, indent=2) + "\n")
    print(json.dumps([{**{k: v for k, v in row.items() if k != "repeats"}, "examples": row["repeats"][:8]} for row in reports], indent=2))


if __name__ == "__main__":
    main()
