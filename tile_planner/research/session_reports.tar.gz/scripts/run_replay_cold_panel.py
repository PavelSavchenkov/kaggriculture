"""Real replay biology with fixed trades: preparation repair and placement."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/replay_cold_panel_001"


def main():
    inputs = json.loads((EXP / "runs/replay_lives_002/MANIFEST.json").read_text())["courses"]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    panel = {}
    for case in sorted(inputs, key=lambda x: (x["episode"], x["seat"])):
        if case.get("biological_contract_verified"):
            panel.setdefault(case["team"], case)
    OUTPUT.mkdir(exist_ok=False)
    names = ["compile_cold", "search_lives", "export_calendar"]
    for name in names:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/replay_bank_001.bin", OUTPUT / "BANK.bin")
    tasks = [{**case, "method": method, "seed": int((EXP / traces[case["episode"]]).read_text().split()[0])}
             for case in panel.values() for method in ["source_no_preparation", "source_preparation_micro", "source_preparation_refine", "local_preparation_micro"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "day_seconds": 9, "query_seconds": 3,
        "warm_micro_seconds": 0.1, "search_seconds_per_variant": 3, "weed_chance": 0.005,
        "opponent": "live public_router", "seeds_and_seats": "source replay seed and seat; native shops",
        "bank": "frozen original 44 cold courses plus all 48 development source courses; construction separately recorded",
        "scope": "six development representatives; DeeperNet and mtmr_s1 are related; fixed biological and trade commitments, derived preparation",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in names},
        "bank_sha256": hashlib.sha256((OUTPUT / "BANK.bin").read_bytes()).hexdigest()}, indent=2) + "\n")

    def search(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}_search"
        source = EXP / case["output"]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(OUTPUT / "search_lives"), str(source / "INPUT.plan"), str(folder), "3", "512019",
                str(source / "assignment.txt"), str(EXP / case["source_course"])], stdout=stream, stderr=subprocess.STDOUT)
        return result.returncode

    with ThreadPoolExecutor(max_workers=4) as pool:
        codes = list(pool.map(search, panel.values()))
    if any(codes):
        raise RuntimeError("real-input proposal generation failed; inspect logs")

    def run(task):
        name = f"{task['episode']}_{task['seat']}_{task['method']}"
        folder = OUTPUT / name; source = EXP / task["output"]
        assignment = source / "assignment.txt"
        if task["method"] == "local_preparation_micro":
            assignment = OUTPUT / f"{task['episode']}_{task['seat']}_search/local_lives/assignment.txt"
        repair = task["method"] != "source_no_preparation"
        warm = 9 if task["method"] == "source_preparation_refine" else 0.1
        command = [str(OUTPUT / "compile_cold"), str(source / "INPUT.plan"), str(folder), str(assignment), "9", "3", str(task["seed"]), "0.005",
            "--seat", str(task["seat"]), "--opponent", "public_router", "--finance_source", str(EXP / task["source_course"]),
            "--bank", str(OUTPUT / "BANK.bin"), "--warm_seconds", str(warm), "--repair_preparation", str(int(repair))]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), *command], stdout=stream, stderr=subprocess.STDOUT)
        row = {"team": task["team"], "episode": task["episode"], "seat": task["seat"], "method": task["method"],
               "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), str(task["seed"]), "0.005", str(task["seat"]), str(folder / "calendar")],
                    stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
