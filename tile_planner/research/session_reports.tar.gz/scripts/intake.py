"""Download public evidence with source-team splits fixed before replay inspection."""
import argparse
import csv
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path


EXP = Path(__file__).resolve().parents[1]


def command(*args):
    return subprocess.run(["conda", "run", "-n", "kaggriculture", "kaggle", *map(str, args)],
                          check=True, capture_output=True, text=True, timeout=180).stdout


def query(path, *args):
    if path.exists():
        return json.loads(path.read_text())
    value = json.JSONDecoder().raw_decode(command(*args).lstrip())[0]
    path.write_text(json.dumps(value, indent=2) + "\n")
    return value


def initialize():
    path = EXP / "research/FAMILY_SPLITS.json"
    if path.exists():
        return json.loads(path.read_text())
    board = max((EXP / "research/leaderboard").glob("*-publicleaderboard-*.csv"))
    with board.open(encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))[:18]
    data = {"utc": datetime.now(timezone.utc).isoformat(), "leaderboard": str(board.relative_to(EXP)),
            "sha256": hashlib.sha256(board.read_bytes()).hexdigest(),
            "rule": "Ranks modulo 4: 1/2 development, 3 validation, 0 final. Top 18. Split before new replay inspection; audit shared tape families before final claims.",
            "teams": [{"rank": int(r["Rank"]), "team_id": int(r["TeamId"]), "name": r["TeamName"],
                       "score": float(r["Score"]), "users": r["TeamMemberUserNames"],
                       "split": "final" if int(r["Rank"]) % 4 == 0 else "validation" if int(r["Rank"]) % 4 == 3 else "development"}
                      for r in rows]}
    path.write_text(json.dumps(data, indent=2) + "\n")
    return data


def fetch(team, output, count):
    team_path = output / f"team_{team['team_id']}"
    team_path.mkdir(exist_ok=True)
    submissions = query(team_path / "submissions.json", "competitions", "team-submissions", team["team_id"], "--format", "json")
    rated = [s for s in submissions if s.get("publicScore") is not None]
    if not rated:
        return {**team, "status": "no_rated_submission", "episodes": []}
    submission = max(rated, key=lambda s: float(s["publicScore"]))
    episodes = query(team_path / "episodes.json", "competitions", "episodes", submission["id"], "--format", "json")
    selected = sorted((e for e in episodes if e["state"] == "EpisodeState.COMPLETED"),
                      key=lambda e: e["createTime"], reverse=True)[:count]
    result = {**team, "status": "downloaded", "submission_id": submission["id"],
              "submission_score": submission["publicScore"], "episodes": []}
    for episode in selected:
        number = int(episode["id"])
        path = team_path / f"episode-{number}-replay.json"
        if not path.exists():
            command("competitions", "replay", number, "-p", team_path, "-q")
        body = path.read_bytes()
        if not body:
            raise ValueError(f"empty replay {number}")
        result["episodes"].append({"episode_id": number, "created": episode["createTime"],
                                   "file": str(path.relative_to(EXP)), "sha256": hashlib.sha256(body).hexdigest()})
    (team_path / "DOWNLOAD.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"rank {team['rank']} {team['name']}: {len(selected)} replays", flush=True)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("split", choices=["metadata", "development", "validation", "final"])
    parser.add_argument("--episodes", type=int, default=6)
    parser.add_argument("--round", default="initial")
    parser.add_argument("--max-rank", type=int, default=12)
    args = parser.parse_args()
    splits = initialize()
    if args.split == "metadata":
        print(json.dumps(splits, indent=2))
        return
    output = EXP / "replays" / f"{args.split}_{args.round}"
    output.mkdir(exist_ok=True)
    teams = [t for t in splits["teams"] if t["split"] == args.split and t["rank"] <= args.max_rank]
    results = []
    with ThreadPoolExecutor(max_workers=3) as pool:
        pending = [pool.submit(fetch, t, output, args.episodes) for t in teams]
        for future in as_completed(pending):
            results.append(future.result())
            (output / "DOWNLOAD.json").write_text(json.dumps({"complete": len(results) == len(teams),
                "utc": datetime.now(timezone.utc).isoformat(), "split": args.split,
                "teams": sorted(results, key=lambda t: t["rank"])}, indent=2) + "\n")


if __name__ == "__main__":
    main()
