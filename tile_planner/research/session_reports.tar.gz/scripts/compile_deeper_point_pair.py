"""Complete the one newly feasible diagnostic proposal and its stronger control."""
import json
import shutil
import subprocess
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/final_deeper_course_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    source = EXP / "runs/distinct_bounded_panel_001/107375473_0_public_router_9_search"
    original = source / "incumbent"
    context = json.loads((original / "SUMMARY.json").read_text())
    points = EXP / "runs/final_deeper_points_001/107375473_0"
    bank_paths = [original, points / "candidate_23_11", points / "control_unchanged_11"]
    for name in ["compile_cold", "export_calendar", "pack_bank"]:
        shutil.copy2(source / name, OUTPUT / name)
    (OUTPUT / "VALIDATE.txt").write_text(str(original) + "\n")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"scope": "post-freeze deeper-query diagnosis; no promotion claim or learned rule", "proposal": "crop_chain 0:93:62, original frozen ID 23", "day_seconds": 9, "query_seconds": 3, "warm_seconds": 0,
        "control": "same original layout and bank; also receives every strictly replayable new candidate-day witness, including a failed course prefix", "context": context}, indent=2) + "\n")
    rows = []
    for label, assignment in [("candidate", source / "proposals/23/assignment.txt"), ("control", original / "assignment.txt")]:
        manifest = OUTPUT / f"BANK_{label}.txt"
        manifest.write_text("".join(str(path) + "\n" for path in bank_paths))
        bank = OUTPUT / f"BANK_{label}.bin"
        with (OUTPUT / f"pack_{label}.log").open("w") as stream:
            subprocess.run(list(map(str, [OUTPUT / "pack_bank", manifest, bank, OUTPUT / "VALIDATE.txt"])), stdout=stream, stderr=subprocess.STDOUT, check=True)
        folder = OUTPUT / label
        command = [OUTPUT / "compile_cold", original / "INPUT.plan", folder, assignment, 9, 3, context["seed"], context["weed_chance"], "--bank", bank, "--warm_seconds", 0, "--opponent", "public_router", "--seat", context["seat"], "--finance_source", context["finance_source"], "--repair_preparation", 1]
        with (OUTPUT / f"{label}.log").open("w") as stream:
            result = subprocess.run(list(map(str, command)), stdout=stream, stderr=subprocess.STDOUT, timeout=600)
        row = {"method": label, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run(list(map(str, [OUTPUT / "export_calendar", folder, context["seed"], context["weed_chance"], context["seat"], folder / "calendar"])), stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        rows.append(row)
        bank_paths.append(folder)
        (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")
        print(json.dumps(row), flush=True)


if __name__ == "__main__":
    main()
