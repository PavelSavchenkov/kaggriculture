"""Unseen lifetime counts and calendars: cold compile versus strict reuse."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
INPUT = EXP / "runs/new_inputs_001"
OUTPUT = EXP / "runs/new_input_panel_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar", "search_lives"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/cold_bank_001.txt", OUTPUT / "BANK.txt")
    names = [row["name"] for row in csv.DictReader((INPUT / "cases.csv").open())]
    tasks = [{"case": name, "method": method, "reuse": reuse} for name in names
        for method, reuse in [("animals", "self_refine"), ("animals", "bank_fast"), ("animals", "bank_refine"), ("local_lives", "bank_fast")]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "day_seconds": 6, "query_seconds": 2,
        "seed": 4001, "shop_seed": 5003, "weed_chance": 0.005, "seat": 0, "opponent": "live public_router",
        "search_seconds_per_variant": 3, "bank": "frozen original 44 complete cold courses; no new input certificates",
        "comparison": "self_refine versus bank_fast measures time and any quality tradeoff; bank_refine gives matched per-day solving; local_lives is a placement candidate",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar", "search_lives"]}}, indent=2) + "\n")

    def search(name):
        with (OUTPUT / (name + "_search.log")).open("w") as stream:
            result = subprocess.run([str(OUTPUT / "search_lives"), str(INPUT / (name + ".plan")), str(OUTPUT / (name + "_search")), "3", "4001"], stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"search failed: {name}")

    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(search, names))

    def run(task):
        name = f"{task['case']}_{task['method']}_{task['reuse']}"
        folder = OUTPUT / name
        assignment = "animals" if task["method"] == "animals" else str(OUTPUT / (task["case"] + "_search") / "local_lives/assignment.txt")
        reuse = ["--reuse", "self"] if task["reuse"] == "self_refine" else ["--bank", str(OUTPUT / "BANK.txt")]
        if task["reuse"] == "bank_fast":
            reuse += ["--refine", "0"]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"),
                str(INPUT / (task["case"] + ".plan")), str(folder), assignment, "6", "2", "4001", "0.005", "--opponent", "public_router",
                "--shop_seed", "5003", *reuse], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), "4001", "0.005", "0", str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
