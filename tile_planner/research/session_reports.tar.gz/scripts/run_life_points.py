"""Fixed-workforce placement interventions, with matched unchanged controls."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
SOURCE = EXP / "runs/life_probes_001"
OUTPUT = EXP / "runs/life_points_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    binary = OUTPUT / "solve_point"
    shutil.copy2(EXP / "build/solve_point", binary)
    probes = [row for row in csv.DictReader((SOURCE / "probes.csv").open()) if row["selected"] == "1"]
    tasks = [{**row, "day": day, "workers": 13, "seconds": 6} for row in probes for day in [20, 24]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
        "claim_scope": "point feasibility only; a positive intervention still needs full-course compilation and replay",
        "selection": "per family: three best peak predictions, worst prediction, four uniform samples; deduplicated"}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['id']}_{task['day']}"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(binary), str(SOURCE / task["id"] / str(task["day"])), str(task["day"]),
                str(task["workers"]), str(task["seconds"]), str(folder)], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-1000:]
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
