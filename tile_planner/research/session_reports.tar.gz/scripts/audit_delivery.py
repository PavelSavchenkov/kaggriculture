"""Verify the frozen comparison, source archive and retained evidence hashes."""
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
REPO = EXP.parents[2]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    checks = {}
    panel = EXP / "runs/final_panel_001"
    protocol = json.loads((panel / "PROTOCOL.json").read_text())
    for name, expected in protocol["binary_sha256"].items():
        checks[f"frozen_binary:{name}"] = digest(panel / "tools" / name) == expected
    checks["frozen_optimizer"] = digest(panel / "optimize_placement.py") == protocol["launcher_sha256"]
    checks["frozen_panel_launcher"] = digest(panel / "run_final_panel.py") == protocol["panel_sha256"]

    package = json.loads((EXP / "artifacts/PACKAGE.json").read_text())
    checks["source_archive"] = digest(EXP / package["archive"]) == package["sha256"]
    staged = EXP / package["staged_repository"]
    core = []
    with tarfile.open(EXP / package["archive"], "r:gz") as archive:
        files = {member.name: member for member in archive.getmembers() if member.isfile()}
        checks["archive_file_set"] = set(files) == set(package["source_files_sha256"])
        for name, expected in package["source_files_sha256"].items():
            checks[f"archive_file:{name}"] = hashlib.sha256(archive.extractfile(files[name]).read()).hexdigest() == expected
            checks[f"clean_build_file:{name}"] = digest(staged / name) == expected
            relative = Path(name).relative_to(EXP.relative_to(REPO))
            if relative.parts[0] in ["include", "source"] or str(relative) in ["CMakeLists.txt", "scripts/optimize_placement.py"]:
                checks[f"current_core:{relative}"] = digest(EXP / relative) == expected
                core.append(str(relative))

    results = json.loads((EXP / "RESULTS.json").read_text())
    for name, expected in results["source_sha256"].items():
        checks[f"result_evidence:{name}"] = digest(EXP / name) == expected
    provenance = json.loads((EXP / "evidence/PRIOR_REVIEW_PROVENANCE.json").read_text())
    checks["root_pdf"] = digest(REPO / "agent_development_strategy_sep08.pdf") == provenance["root_pdf_sha256"]
    for item in provenance["artifacts"]:
        checks[f"initial_review:{item['name']}"] = digest(EXP / "evidence" / item["name"]) == item["sha256"]
    runtime = json.loads((EXP / "artifacts/RUNTIME_DEPENDENCIES.json").read_text())
    for name, item in runtime["repository_libraries"].items():
        checks[f"runtime:{name}"] = digest(REPO / name) == item["sha256"]

    report = {"checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "hash integrity of frozen tools, packed source and clean build, current core, result sources, initial review and root runtime dependencies; this does not infer statistical independence or rerun optimization",
        "archive_sha256": package["sha256"], "current_core_files_matching_archive": len(core),
        "checks": checks, "passed": all(checks.values()), "failed": [name for name, passed in checks.items() if not passed]}
    (EXP / "artifacts/DELIVERY_AUDIT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ["checked_at_utc", "current_core_files_matching_archive", "passed", "failed"]} | {"checks": len(checks)}))
    assert report["passed"], report["failed"]


if __name__ == "__main__":
    main()
