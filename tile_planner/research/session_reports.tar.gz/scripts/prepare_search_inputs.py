"""Copy complete incumbent courses and restore context from their frozen protocols."""
import json
import shutil
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/search_inputs_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    sources = {"expanding36": "probe_courses_001/0", "expanding32": "new_input_panel_001/expanding32_animals_bank_refine",
        "wheat23": "new_input_panel_001/wheat23_animals_self_refine", "mixed_delayed": "new_input_panel_001/mixed_delayed_animals_bank_refine",
        "mixed_low_care": "new_input_panel_001/mixed_low_care_animals_bank_refine", "carrot10": "new_input_panel_001/carrot10_animals_self_refine"}
    records = []
    for name, relative in sources.items():
        source = EXP / "runs" / relative
        folder = OUTPUT / name
        shutil.copytree(source, folder)
        summary = json.loads((folder / "SUMMARY.json").read_text())
        if not summary["complete"] or not (folder / "calendar/CALENDAR.json").exists():
            raise ValueError("input course is not independently verified")
        context = {"seed": 1009, "weed_chance": 0} if name == "expanding36" else {"seed": 4001, "weed_chance": 0.005}
        summary.update(context)
        (folder / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
        record = {"case": name, "source": str(source.relative_to(EXP)), "context_added": context,
            "context_source": str((source.parent / "PROTOCOL.json").relative_to(EXP)),
            "note": "Copied schedules and certificates unchanged; seed/weed metadata restored from the original frozen run protocol."}
        (folder / "COPY_PROVENANCE.json").write_text(json.dumps(record, indent=2) + "\n")
        records.append(record)
    (OUTPUT / "PROVENANCE.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
