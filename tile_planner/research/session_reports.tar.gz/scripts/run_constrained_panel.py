"""Run equal-radius and legal dated searches on the fixed development panel."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/constrained_search_001"


def main():
    panel = json.loads((EXP / "runs/swap_probes_002/PANEL.json").read_text())["cases"]
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/search_constrained", OUTPUT / "search_constrained")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": panel, "seconds_per_search": 9, "workers": 2, "seed": 104729,
        "methods": ["equal_radius_local", "equal_radius_global", "equal_radius_quadrant", "dated_equal_radius", "dated_same_quadrant", "dated_owned_cross_quadrant"],
        "maximum_dated_swaps": 4, "donors": [case["course"] for case in panel],
        "binary_sha256": hashlib.sha256((OUTPUT / "search_constrained").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}"
        with folder.with_suffix(".log").open("w") as stream:
            completed = subprocess.run([str(OUTPUT / "search_constrained"), str(EXP / case["course"]), str(folder), "9", "104729",
                *(str(EXP / donor["course"]) for donor in panel)], stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "returncode": completed.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, panel))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
