"""Describe frozen query outcomes and time allocation; no new method fitting."""
import json
from collections import Counter, defaultdict
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    panels = {
        "synthetic_development": ("runs/bounded_panel_002", "*/RESULT.json"),
        "real_development": ("runs/real_bounded_panel_002", "*/RESULT.json"),
        "frozen_final": ("runs/final_panel_001", "*/bounded_*/RESULT.json"),
        "distinct_extension": ("runs/distinct_bounded_panel_001", "*/RESULT.json"),
    }
    result = {}
    for label, (folder, pattern) in panels.items():
        cases = []
        for path in sorted((EXP / folder).glob(pattern)):
            row = json.loads(path.read_text())
            if row.get("mode") != "search" or row["budget_seconds"] != 180:
                continue
            times = defaultdict(float)
            for event in row["events"]:
                kind = event["tool"]
                if kind == "solve_point":
                    kind = "placement_day_queries" if event["label"].startswith("point_") else "unchanged_day_queries"
                elif kind == "compile_cold":
                    kind = "changed_course_compile" if event["label"].startswith("candidate_") else "unchanged_course_compile"
                times[kind] += event["seconds"]
            statuses = Counter()
            for point in (path.parent / "points").glob("*/*/SUMMARY.json"):
                state = json.loads(point.read_text())
                kind = "placement" if point.parent.parent.name.isdigit() else "unchanged"
                statuses[kind + "_" + state["status"]] += 1
            outcomes = []
            verified = {entry["path"] for entry in row["complete_candidates"]}
            for event in row["events"]:
                if event["tool"] != "compile_cold" or not event["label"].startswith("candidate_"):
                    continue
                candidate = path.parent / event["label"]
                summary = json.loads((candidate / "SUMMARY.json").read_text()) if (candidate / "SUMMARY.json").exists() else {}
                outcome = "verified_complete" if candidate.name in verified else "timeout" if event["status"] == "timeout" else summary.get("failure") or "failed_without_complete_certificate"
                outcomes.append({"candidate": candidate.name, "outcome": outcome, "seconds": event["seconds"], "complete_bill": summary.get("hire_bill") if summary.get("complete") else None, "complete_cash": summary.get("cash") if summary.get("complete") else None})
            cases.append({"source": str(path.relative_to(EXP)), "seconds_by_operation": dict(times), "point_statuses": dict(statuses), "changed_courses": outcomes, "elapsed_seconds": row["elapsed_seconds"]})
        totals = defaultdict(float)
        statuses = Counter()
        for case in cases:
            for kind, seconds in case["seconds_by_operation"].items():
                totals[kind] += seconds
            statuses.update(case["point_statuses"])
        result[label] = {"cases": cases, "total_seconds_by_operation": dict(totals), "point_statuses": dict(statuses)}
    output = {"scope": "descriptive 180-second search-run accounting; cases and day queries are dependent, and UNKNOWN is not infeasible", "panels": result}
    (EXP / "research/search_time_001.json").write_text(json.dumps(output, indent=2) + "\n")
    for label, panel in result.items():
        print(json.dumps({"panel": label, "cases": len(panel["cases"]), "seconds": panel["total_seconds_by_operation"], "points": panel["point_statuses"]}))


if __name__ == "__main__":
    main()
