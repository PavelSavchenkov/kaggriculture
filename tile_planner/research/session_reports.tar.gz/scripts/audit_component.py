"""Record component sources, actual repository build dependencies and doc links."""
import hashlib
import json
import re
import shlex
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
REPO = EXP.parents[2]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    source_files = [EXP / "CMakeLists.txt"]
    for folder in ["include", "source", "scripts"]:
        source_files.extend(path for path in (EXP / folder).rglob("*") if path.is_file() and path.suffix in [".hpp", ".cpp", ".py", ".json"])
    dependencies = set()
    for depfile in (EXP / "build").rglob("*.o.d"):
        for token in shlex.split(depfile.read_text().replace("\\\n", " ")):
            if token.endswith(":"):
                continue
            path = Path(token)
            if not path.is_absolute() or not path.is_file():
                continue
            path = path.resolve()
            if path.is_relative_to(REPO) and not path.is_relative_to(EXP):
                dependencies.add(path)
    other_experiments = [str(path.relative_to(REPO)) for path in dependencies if path.is_relative_to(REPO / "experiments")]
    docs = list(EXP.glob("*.md")) + list((EXP / "examples").rglob("README.md"))
    broken = []
    checked = 0
    for doc in docs:
        for target in re.findall(r"\[[^\]]*\]\(([^)]+)\)", doc.read_text()):
            target = target.strip("<>").split("#", 1)[0]
            if not target or "://" in target:
                continue
            checked += 1
            if not (doc.parent / target).exists():
                broken.append({"document": str(doc.relative_to(EXP)), "target": target})
    report = {"scope": "current component code and repository dependencies discovered from the complete local build; system/Conda headers and libraries remain environment dependencies",
        "component_sha256": {str(path.relative_to(EXP)): digest(path) for path in sorted(source_files)},
        "repository_dependency_sha256": {str(path.relative_to(REPO)): digest(path) for path in sorted(dependencies)},
        "repository_dependency_roots": sorted({path.relative_to(REPO).parts[0] for path in dependencies}),
        "other_experiment_build_dependencies": other_experiments, "checked_document_links": checked, "broken_document_links": broken,
        "entrypoint_binary_sha256": {name: digest(EXP / "build" / name) for name in ["compile_cold", "export_calendar", "probe_lives", "solve_point", "pack_bank", "import_lives", "search_lives"]}}
    (EXP / "COMPONENT_MANIFEST.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"component_files": len(source_files), "repository_dependencies": len(dependencies), "dependency_roots": report["repository_dependency_roots"], "other_experiments": other_experiments, "checked_document_links": checked, "broken_document_links": broken}))
    assert not other_experiments and not broken


if __name__ == "__main__":
    main()
