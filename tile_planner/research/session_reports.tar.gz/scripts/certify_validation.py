"""Frozen cow/sheep swap selectors on every reserved validation course."""
import csv
import hashlib
import json
import random
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
SOURCE = EXP / "runs/validation_sources_001"
OUTPUT = EXP / "runs/validation_swaps_001"


def main():
    cases = json.loads((SOURCE / "MANIFEST.json").read_text())["courses"]
    if any(row.get("valid_day_contracts") != 30 or not row.get("replay", {}).get("valid") for row in cases):
        raise ValueError("validation source coverage failed")
    OUTPUT.mkdir(exist_ok=False)
    names = ["certify_course", "replay_course"]
    for name in names:
        shutil.copy2(SOURCE / name, OUTPUT / name)
    tasks = []
    for case in cases:
        probes = EXP / case["course"] / "probes"
        swaps = list(csv.DictReader((probes / "swaps.csv").open()))
        choices = [("source", "source")]
        if swaps:
            predicted = min(swaps, key=lambda r: (float(r["predicted_cost"]), r["name"]))
            retained = min(swaps, key=lambda r: (-int(r["retained_days"]) - int(r["rerouted_days"]), float(r["predicted_cost"]), r["name"]))
            choices += [("predicted", predicted["name"]), ("retained", retained["name"])]
            unused = [r for r in swaps if r["name"] not in {predicted["name"], retained["name"]}]
            if unused:
                choices.append(("random", random.Random(20260910 + case["episode"] * 2 + case["seat"]).choice(unused)["name"]))
        seen = set()
        for method, intervention in choices:
            if intervention in seen:
                continue
            seen.add(intervention)
            tasks.append({**case, "id": f"{case['episode']}_{case['seat']}_{method}", "method": method,
                          "intervention": intervention, "layout": str((probes / (intervention + ".layout.txt")).relative_to(EXP))})
    protocol = {"tasks": tasks, "workers": 4, "per_day_seconds": 9, "query_seconds": 3,
        "selectors": "minimum predicted total bill; maximum retained-or-reroutable source days then prediction; one uniform remaining swap",
        "comparison": "unchanged layout has the same refinement budget; partial candidates never replace it",
        "scope": "validation of existing selectors; no demand fitting; source continuation is replayed rather than a live opponent",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in names}}
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps(protocol, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / task["id"]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")),
                str(OUTPUT / "certify_course"), str(EXP / task["course"]), str(EXP / task["layout"]), str(folder), "9", "3"],
                stdout=stream, stderr=subprocess.STDOUT)
        row = {"id": task["id"], "team": task["team"], "team_id": task["team_id"], "episode": task["episode"],
               "seat": task["seat"], "method": task["method"], "returncode": result.returncode, "intervention": task["intervention"]}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        if row.get("complete"):
            for mode in ["native", "fixed_shops"]:
                report = folder / f"REPLAY_{mode}.json"
                with (folder / f"replay_{mode}.log").open("w") as stream:
                    check = subprocess.run([str(OUTPUT / "replay_course"), str(EXP / task["trace"]), str(task["seat"]),
                        str(folder), str(EXP / task["layout"]), str(report), mode], stdout=stream, stderr=subprocess.STDOUT)
                row[f"replay_{mode}"] = json.loads(report.read_text()) if report.exists() else {"returncode": check.returncode}
            row["full_engine_verified"] = all(row[f"replay_{mode}"].get("valid", False) for mode in ["native", "fixed_shops"])
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
