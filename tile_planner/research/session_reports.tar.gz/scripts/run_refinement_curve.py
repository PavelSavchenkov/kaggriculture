"""Development-only original-layout quality/time curve; frozen before this run."""
import hashlib
import json
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/refinement_curve_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    cases = [task for task in json.loads((EXP / "runs/replay_recorded_panel_002/PROTOCOL.json").read_text())["tasks"] if task["method"].endswith("micro")]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: EXP / game["trace"] for game in games}
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/replay_bank_001.bin", OUTPUT / "BANK.bin")
    tasks = [{**case, "warm": warm} for warm in [0, 0.1, 0.5, 2, 9] for case in cases]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "scope": "development-only profiling; original supplied assignment, source finance, native seed/seat and recorded opponent",
        "settings": "9-second day cap and 3-second query cap on days without a certificate; only the cap on refining an existing strict witness varies",
        "bank": "fixed development bank; no sharing of new witnesses across runs; bank construction excluded and reported separately",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar", "BANK.bin"]}}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['episode']}_{task['seat']}_warm_{str(task['warm']).replace('.', 'p')}"
        imported = EXP / task["output"]
        command = [OUTPUT / "compile_cold", imported / "INPUT.plan", folder, imported / "assignment.txt", 9, 3, task["seed"], 0.005,
            "--seat", task["seat"], "--opponent", "recorded", "--opponent_trace", traces[task["episode"]],
            "--finance_source", EXP / task["source_course"], "--bank", OUTPUT / "BANK.bin", "--warm_seconds", task["warm"], "--repair_preparation", 1]
        began = time.monotonic()
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-f", "{\"user_seconds\":%U,\"system_seconds\":%S,\"max_rss_kib\":%M,\"wall_seconds\":%e}", "-o", str(folder.with_suffix(".time.json")), *map(str, command)], stdout=stream, stderr=subprocess.STDOUT, timeout=600)
        row = {"team": task["team"], "episode": task["episode"], "seat": task["seat"], "warm": task["warm"], "returncode": result.returncode, "output": str(folder.relative_to(EXP)), "process_seconds": time.monotonic() - began}
        timing = folder.with_suffix(".time.json").read_text().splitlines()[-1]
        row["process_profile"] = json.loads(timing)
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            began = time.monotonic()
            with (folder / "calendar.log").open("w") as stream:
                verified = subprocess.run(list(map(str, [OUTPUT / "export_calendar", folder, task["seed"], 0.005, task["seat"], folder / "calendar"])), stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = verified.returncode == 0
            row["verification_seconds"] = time.monotonic() - began
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
