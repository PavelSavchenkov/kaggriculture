"""Fresh-seed live-opponent transfer of frozen placements and schedule bank."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/cold_live_001"


def main():
    cases = ["wheat12", "dairy", "mixed_animals", "geese", "crop_rotation", "expanding_mixed"]
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(EXP / "runs/cold_bank_001.txt", OUTPUT / "BANK.txt")
    tasks = []
    for case in cases:
        for method in ["animals" if case == "expanding_mixed" else "nearest", "local_lives"]:
            assignment = EXP / "runs/life_search_002" / case / method / "assignment.txt"
            for seed in [1013, 2017]:
                for seat in [0, 1]:
                    for finance in ["dawn", "immediate_goods"]:
                        tasks.append({"case": case, "method": method, "assignment": str(assignment.relative_to(EXP)), "seed": seed, "seat": seat, "finance": finance})
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "day_seconds": 9, "query_seconds": 3,
        "opponent": "live public_router from persistent agent catalog", "weed_chance": 0.005,
        "bank": "44 complete development cold courses, seed 1009; strict replay on each new day; bounded weed repair; solve only missing days",
        "claim_scope": "functional transfer and speed; candidate-dependent missing-day solves are not matched-budget placement-quality evidence",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]},
        "bank_manifest_sha256": hashlib.sha256((OUTPUT / "BANK.txt").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        name = f"{case['case']}_{case['method']}_{case['seed']}_{case['seat']}_{case['finance']}"
        folder = OUTPUT / name
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"), case["case"],
                str(folder), str(EXP / case["assignment"]), "9", "3", str(case["seed"]), "0.005", "--bank", str(OUTPUT / "BANK.txt"),
                "--opponent", "public_router", "--seat", str(case["seat"]), "--finance", case["finance"], "--refine", "0"], stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                checked = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), str(case["seed"]), "0.005", str(case["seat"]),
                    str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = checked.returncode == 0
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
