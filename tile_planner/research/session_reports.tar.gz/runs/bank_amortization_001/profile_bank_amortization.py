"""Measure one-time bank packing and validation, excluding route discovery."""
import hashlib
import json
import math
import random
import shutil
import statistics
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/bank_amortization_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/pack_bank", OUTPUT / "pack_bank")
    shutil.copy2(__file__, OUTPUT / "profile_bank_amortization.py")
    cases = [
        {"name": "rotation_9", "input": "examples/rotation/SOURCE_BANK.txt", "validation": "examples/rotation/SOURCE_BANK.txt", "existing": "examples/rotation/BANK.bin"},
        {"name": "real_30", "input": "runs/life_compile_reuse_benchmark_001/107374327_0/BANK.txt", "validation": "runs/life_compile_reuse_benchmark_001/107374327_0/BANK.txt", "existing": "runs/life_compile_reuse_benchmark_001/107374327_0/BANK.bin"},
        {"name": "synthetic_269", "input": "runs/cold_bank_001.txt", "validation": "runs/bank_validation_001.txt", "existing": "runs/cold_bank_001.bin"},
        {"name": "development_1212", "input": "runs/replay_bank_001.txt", "validation": "runs/replay_bank_validation_001.txt", "existing": "runs/replay_bank_001.bin"},
    ]
    tasks = [{**case, "repeat": repeat} for case in cases for repeat in range(3)]
    random.Random(9124).shuffle(tasks)
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 2,
        "scope": "packing and strict lookup validation from existing certificates; original route discovery is still excluded; no placement or finance changes",
        "binary_sha256": hashlib.sha256((OUTPUT / "pack_bank").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(task):
        label = task["name"] + "_" + str(task["repeat"])
        bank = OUTPUT / (label + ".bin")
        profile = OUTPUT / (label + ".time.json")
        began = time.monotonic()
        with (OUTPUT / (label + ".log")).open("w") as stream:
            subprocess.run(["/usr/bin/time", "-f", "{\"user_seconds\":%U,\"system_seconds\":%S,\"max_rss_kib\":%M}", "-o", str(profile),
                str(OUTPUT / "pack_bank"), str(EXP / task["input"]), str(bank), str(EXP / task["validation"])], stdout=stream, stderr=subprocess.STDOUT, check=True)
        row = {**task, "pack_and_validate_wall_seconds": time.monotonic() - began}
        row.update(json.loads((OUTPUT / (label + ".log")).read_text()))
        row["profile"] = json.loads(profile.read_text())
        row["identical_to_existing"] = hashlib.sha256(bank.read_bytes()).digest() == hashlib.sha256((EXP / task["existing"]).read_bytes()).digest()
        assert row["identical_to_existing"]
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, tasks))
    summaries = []
    for case in cases:
        selected = [row for row in rows if row["name"] == case["name"]]
        packing = statistics.mean(row["pack_and_validate_wall_seconds"] for row in selected)
        saving = statistics.mean(row["original_load_seconds"] - row["packed_load_seconds"] for row in selected)
        summaries.append({"name": case["name"], "entries": selected[0]["entries"], "bytes": selected[0]["bytes"],
            "mean_pack_and_validate_wall_seconds": packing, "mean_load_saving_seconds": saving,
            "load_only_break_even_uses": math.ceil(packing / saving),
            "max_rss_kib": max(row["profile"]["max_rss_kib"] for row in selected)})
    report = {"rows": rows, "summaries": summaries, "all_packed_bytes_identical": all(row["identical_to_existing"] for row in rows),
        "break_even_scope": "ceiling of measured pack-plus-validation wall time divided by internal per-load time saving; approximate, includes different process overhead scopes and excludes discovery of source schedules"}
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}, indent=2))


if __name__ == "__main__":
    main()
