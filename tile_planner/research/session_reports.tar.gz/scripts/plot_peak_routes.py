"""Static placement and certified worker-load figures for the measured peak."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import ListedColormap
from matplotlib.patches import Patch, Rectangle

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "research/peak_route_profiles_001"
CASES = [("control", "0", "Original placement"), ("crop", "1950", "Later crop moved"),
         ("animal", "2717", "Cow / sheep swapped"), ("quadrant", "3125", "Crop counts by quadrant changed")]


def main():
    colors = ["#e8e8e8", "#ffffff", "#edc761", "#5b9bd5", "#cb7377", "#86af7c"]
    labels = {0: (2, "W"), 10: (3, "C"), 11: (4, "S"), 9: (5, "G")}
    fig, axes = plt.subplots(1, 4, figsize=(15, 4.6), constrained_layout=True)
    totals = []
    for ax, (name, case, title) in zip(axes, CASES):
        folder = EXP / "runs/probe_courses_001" / case
        problem = json.loads((folder / "20/problem.json").read_text())
        board = np.zeros((10, 10), dtype=int)
        for cell in range(100):
            y, x = divmod(cell, 10)
            if x < 5 or y < 5:
                board[y, x] = 1
        lives = list(csv.DictReader((folder / "lives.csv").open()))
        crop_actions = {}
        for work in problem["tile_work"]:
            tile = problem["start"]["managed_tiles"][work["tile"]]
            crop_actions[tile["y"] * 10 + tile["x"]] = {action["op"] for action in work["actions"]}
        latest = {}
        for life in lives:
            if int(life["begin_day"]) <= 20 <= int(life["release_day"]):
                cell = int(life["cell"])
                if cell not in latest or int(life["begin_day"]) > int(latest[cell]["begin_day"]):
                    latest[cell] = life
        for cell, life in latest.items():
            y, x = divmod(cell, 10)
            color, label = labels[int(life["item"])]
            if int(life["item"]) == 0:
                actions = crop_actions.get(cell, set())
                if "plant" in actions and "harvest" not in actions:
                    label = "Wᴾ"
                elif "harvest" in actions and "plant" not in actions:
                    label = "Wᴴ"
            board[y, x] = color
            ax.text(x, y, label, ha="center", va="center", fontsize=8, color="#18212b")
        ax.imshow(board, cmap=ListedColormap(colors), vmin=0, vmax=5, interpolation="none")
        ax.set_xticks(range(10)); ax.set_yticks(range(10)); ax.tick_params(labelsize=7, length=0)
        ax.set_xticks(np.arange(-0.5, 10, 1), minor=True); ax.set_yticks(np.arange(-0.5, 10, 1), minor=True)
        ax.grid(which="minor", color="#b8b8b8", linewidth=0.4); ax.tick_params(which="minor", length=0)
        ax.axvline(4.5, color="#535353", lw=1.2); ax.axhline(4.5, color="#535353", lw=1.2)
        ax.add_patch(Rectangle((3.5, 3.5), 2, 2, fill=False, ec="#1d1d1d", lw=2))
        ax.set_title(title + f"\n{problem['worker_count']} workers on day 20", fontsize=10)
        workers = list(csv.DictReader((OUTPUT / name / "workers.csv").open()))
        totals.append({"name": name, "title": title, "workers": len(workers),
                       **{key: sum(int(row[key]) for row in workers) for key in ["field", "moves", "resources", "idle"]},
                       "shared_quadrant_workers": sum(sum(int(row[f"q{q}"]) > 0 for q in range(4)) > 1 for row in workers)})
    fig.legend(handles=[Patch(facecolor=colors[color], label=label) for color, label in [(2, "Wheat"), (3, "Cow"), (4, "Sheep"), (5, "Goose"), (0, "Locked")]],
               loc="outside lower center", ncol=5, frameon=False, fontsize=9)
    fig.suptitle("Same dated production plan; four certified placements\nWᴴ: harvest only today · Wᴾ: plant only today", fontsize=13)
    fig.savefig(OUTPUT / "placements.png", dpi=180); fig.savefig(OUTPUT / "placements.svg"); plt.close(fig)
    fig, ax = plt.subplots(figsize=(10, 4), constrained_layout=True)
    left = np.zeros(len(totals)); y = np.arange(len(totals))
    for key, color, label in [("field", "#5b9bd5", "Field work"), ("moves", "#e8b64f", "Movement"),
                              ("resources", "#86af7c", "Pickup / drop"), ("idle", "#d6d6d6", "Idle")]:
        values = np.array([row[key] for row in totals]); ax.barh(y, values, left=left, label=label, color=color)
        for i, value in enumerate(values):
            if value >= 8:
                ax.text(left[i] + value / 2, i, str(value), ha="center", va="center", fontsize=9)
        left += values
    ax.set_yticks(y, [row["title"] for row in totals]); ax.invert_yaxis(); ax.set_xlabel("Worker action slots after hiring")
    ax.set_title("All four schedules perform 204 field actions; shared routes still matter", fontsize=12)
    fig.legend(loc="outside lower center", ncol=4, fontsize=8, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    fig.savefig(OUTPUT / "worker_loads.png", dpi=180); fig.savefig(OUTPUT / "worker_loads.svg"); plt.close(fig)
    (OUTPUT / "ROUTE_TOTALS.json").write_text(json.dumps(totals, indent=2) + "\n")


if __name__ == "__main__":
    main()
