# Placement component source package

This package contains the experiment's C++ sources, lifetime API, bounded optimizer and a small runnable rotation example. It uses the repository's persistent `day_solver`, `fast_day_solver_estimator`, `fast_game_engine` and `agents` directories. It has no build dependency on another experiment.

Extract at the repository root so the source remains at `experiments/v6/sep10_tiles_placement/`. Use the same root dependency versions recorded in `COMPONENT_MANIFEST.json`.

```bash
conda run -n kaggriculture cmake -S experiments/v6/sep10_tiles_placement -B experiments/v6/sep10_tiles_placement/build -DCMAKE_BUILD_TYPE=Release
conda run -n kaggriculture cmake --build experiments/v6/sep10_tiles_placement/build --parallel 2
```

See `examples/rotation/README.md` for a complete zero-query example and independent financial check. `API.md` describes the C++ inputs and outputs. `HANDOFF.md` describes the composition, placement, estimator, day-solver and financial-planner boundaries.

The original experiment's replays and large benchmark outputs are not included. The package is a source handoff, not a submitted agent or a claim that general placement search beats fixed-layout refinement. Exact oracle/day reuse and packed strictly replayed schedules are the supported speed improvements. Whole-course candidate acceptance still requires complete execution and financial verification; retain the complete incumbent on failure or timeout.
