# Tile placement for dated farm plans

Eight-hour research window: September 10, 2026, 00:10:28-08:10:28 UTC.

Improve the compositions-based agent-development pipeline by choosing legal crop and animal locations across a complete remaining plan. Use the existing C++ labor estimator and day solver. Measure complete execution quality and total search cost. A better geometric score or isolated day does not establish success.

- `DESIGN.md`: input, output, scope and objective.
- `HANDOFF.md`, `API.md`: pipeline integration, C++ interfaces and current limits.
- `RESULTS.md`, `RESULTS.json`: decisions, paired results and evidence hashes.
- `SEARCH_COVERAGE.md`: tested ideas, negative results and remaining gaps.
- `examples/rotation/`: small runnable input with a 7.7 KB strict-replay bank.
- [Compact source archive](artifacts/placement_component_source.tar.gz), [clean-build check](artifacts/CLEAN_BUILD_CHECK.json) and [delivery audit](artifacts/DELIVERY_AUDIT.json): reproducible component handoff.
- `PROTOCOL.md`: comparisons, promotion and speed criteria.
- `GATE_DECISION.md`: outcomes against those criteria and evidence not produced.
- `IDEAS.md`, `LEARNINGS.md`, `PROFILING.md`: priorities and positive/negative evidence.
- `STATUS.json`, `reviews/`: current state and 20-minute reviews.
- `research/`, `replays/`: current public evidence, source provenance and placement patterns.
- `include/`, `source/`, `scripts/`, `runs/`: C++ component and reproducible experiments.

Persistent root day_solver, fast_day_solver_estimator, fast_game_engine, agents and public_knowledge may be dependencies. No runtime dependency on another experiment. The sealed September 7 archive is read-only source evidence. No Kaggle submission is authorized.

## Run the component

From the repository root:

```bash
conda run -n kaggriculture cmake -S experiments/v6/sep10_tiles_placement -B experiments/v6/sep10_tiles_placement/build -DCMAKE_BUILD_TYPE=Release
conda run -n kaggriculture cmake --build experiments/v6/sep10_tiles_placement/build --parallel 2
```

The C++ headers implement biological compilation, placement proposals, prediction caches, schedule reuse, repair, exact day queries and whole-game verification. Python scripts launch bounded experiments and collect results; they do not replace the C++ routing or biological kernels.

`compile_cold` takes a lifetime plan, an assignment and an evaluation context:

```text
compile_cold plan new_output row|nearest|animals|assignment_file day_seconds query_seconds seed weed_chance
  [--bank manifest_or_packed_bank]
  [--reuse none|self]
  [--warm_seconds seconds]
  [--refine day_bitmask]
  [--finance_source original_course]
  [--repair_preparation 0|1]
  [--opponent pass|public_router|recorded]
  [--opponent_trace trace_file]
  [--seat 0|1]
  [--shop_seed seed]
```

`--finance_source` supplies the outer planner's existing accepted trades and physical resource commitments. Without it, the driver uses a simple dawn purchase/surplus-sale policy. `--warm_seconds` limits refinement of a day that already has a strict witness; days without a witness keep the full day budget. Preparation repair is optional and every proposed edit is strictly replayed.

The driver saves `INPUT.plan`, `assignment.txt`, thirty daily contracts/actions, the actual opponent actions and revealed shops, and `SUMMARY.json`. Only `complete:true` covers all 719 real transitions. `export_calendar course seed weed_chance seat new_output` separately verifies the financial replay and writes delivered/discarded quantities, resources and trades.

To improve an already complete driver output under a total wall-time budget:

```bash
conda run -n kaggriculture python experiments/v6/sep10_tiles_placement/scripts/optimize_placement.py COMPLETE_COURSE NEW_OUTPUT --seconds 180 --mode search --objective cash
```

Use `--mode fixed` for the unchanged-layout control. `--objective hire`, `cash` and `margin` select the accepted metric. For a valid input, `RESULT.json` points to a complete supplied or verified candidate; failed/unfinished candidates cannot replace it. A failed input verification returns `invalid_incumbent` with no accepted path. The result also lists complete alternatives and the nondominated hire/cash choices. This is an offline scenario optimizer. Runtime conditional placement is a separate interface, tested with only shops revealed at the decision time.

## Input and C++ interfaces

See `API.md` for the lifetime text format, exact header interfaces, supported starts, solver status and cache scope. `import_lives source_course new_output` creates a plan only when the source biology matches the life oracle. The import preserves biological obligations and land dates; it does not claim that a newly derived construction schedule or different financial policy is feasible.

The strong simple assignments remain useful candidates. A greedy construction failure is not proof that the input is infeasible. `search_lives plan new_output seconds seed [incumbent_assignment [finance_source]]` accepts a known assignment and reports unconstructed rule proposals separately.
