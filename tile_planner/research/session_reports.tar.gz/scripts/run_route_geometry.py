"""Source-route travel windows as a cheap placement proposal objective."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/route_geometry_001"


def main():
    courses = json.loads((EXP / "runs/source_courses_v2/MANIFEST.json").read_text())["courses"]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    panel = {}
    for course in sorted(courses, key=lambda r: (r["episode"], r["seat"])):
        panel.setdefault(course["team"], course)
    OUTPUT.mkdir(exist_ok=False)
    names = ["search_route_geometry", "replay_course", "certify_course"]
    for name in names:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": list(panel.values()), "workers": 2,
        "selection": "earliest development course per team; no solver calls during generation; all selected physical completions receive both full replays",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in names}}, indent=2) + "\n")

    def run(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}"
        with folder.with_suffix(".log").open("w") as stream:
            search = subprocess.run([str(OUTPUT / "search_route_geometry"), str(EXP / case["course"]), str(folder)], stdout=stream, stderr=subprocess.STDOUT)
        if search.returncode:
            return {**case, "error": folder.with_suffix(".log").read_text()[-2000:]}
        rows = list(csv.DictReader((folder / "candidates.csv").open()))
        for row in rows:
            if int(row["retained_days"]) != 30:
                continue
            candidate = folder / row["name"]
            for mode in ["native", "fixed_shops"]:
                report = candidate / f"REPLAY_{mode}.json"
                with (candidate / f"replay_{mode}.log").open("w") as stream:
                    check = subprocess.run([str(OUTPUT / "replay_course"), str(EXP / traces[case["episode"]]), str(case["seat"]),
                        str(candidate), str(candidate / "layout.txt"), str(report), mode], stdout=stream, stderr=subprocess.STDOUT)
                row[f"replay_{mode}"] = json.loads(report.read_text()) if report.exists() else {"returncode": check.returncode}
            row["full_engine_verified"] = all(row[f"replay_{mode}"].get("valid") for mode in ["native", "fixed_shops"])
        result = {**case, **json.loads((folder / "SUMMARY.json").read_text()), "output": str(folder.relative_to(EXP)), "candidates": rows}
        (folder / "RESULT.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps({"team": case["team"], "selected": len(rows), "full_valid": sum(row.get("full_engine_verified", False) for row in rows)}), flush=True)
        return result

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, panel.values()))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
