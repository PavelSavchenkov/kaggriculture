"""Keep complete recovery separate from profit on an incomplete repaired plan."""
import collections
import csv
import json
import statistics
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def complete(row):
    return all(int(row[key]) == 0 for key in ["failed_units", "failed_orders", "omitted_commands", "dropped_commands"]) and all(
        int(row[key]) == 1 for key in ["production_exact", "inventory_exact", "tiles_exact"]) and row["advanced_units"] == row["canceled_units"]


def main():
    root = EXP / "runs/repair_panel_001"
    cases = json.loads((root / "SUMMARY.json").read_text())
    assert len(cases) == 48 and all(case["returncode"] == 0 for case in cases)
    groups = collections.defaultdict(list)
    pairs = []
    for case in cases:
        rows = list(csv.DictReader((EXP / case["output"] / "results.csv").open()))
        indexed = {(r["fault"], r["world"], r["mode"]): r for r in rows}
        for base in rows:
            if base["mode"] != "0" or base["kind"] == "clean":
                continue
            variants = [indexed[base["fault"], base["world"], str(mode)] for mode in range(4)]
            record = {"team": case["team"], "episode": case["episode"], "seat": case["seat"], "fault": int(base["fault"]),
                      "kind": base["kind"], "world": base["world"], "money": [float(row["money"]) for row in variants],
                      "complete": [complete(row) for row in variants], "failed_units": [int(row["failed_units"]) for row in variants],
                      "advanced_units": int(variants[3]["advanced_units"]), "cash_attempts": int(variants[3]["cash_attempts"])}
            record["gain"] = record["money"][3] - record["money"][0]
            record["cash_gain"] = record["money"][3] - record["money"][2]
            record["absorption_gain"] = record["money"][2] - record["money"][1]
            pairs.append(record)
            groups[base["world"], base["kind"]].append(record)
    summary = {}
    for (world, kind), rows in sorted(groups.items()):
        gains = [row["gain"] for row in rows]
        cash = [row["cash_gain"] for row in rows]
        absorption = [row["absorption_gain"] for row in rows]
        summary[f"{world}:{kind}"] = {"fault_instances": len(rows), "complete_by_mode": [sum(row["complete"][mode] for row in rows) for mode in range(4)],
            "cash_gain_full_repair_vs_none": {"mean": statistics.mean(gains), "median": statistics.median(gains), "min": min(gains), "max": max(gains),
                "wins": sum(x > 0 for x in gains), "losses": sum(x < 0 for x in gains)},
            "cash_advance_vs_queue": {"mean": statistics.mean(cash), "wins": sum(x > 0 for x in cash), "losses": sum(x < 0 for x in cash)},
            "pass_absorption_vs_plain_queue": {"mean": statistics.mean(absorption), "wins": sum(x > 0 for x in absorption), "losses": sum(x < 0 for x in absorption)},
            "teams": {team: {"instances": len(part := [row for row in rows if row["team"] == team]),
                              "mean_gain": statistics.mean(row["gain"] for row in part), "complete_mode3": sum(row["complete"][3] for row in part)}
                      for team in sorted({row["team"] for row in rows})}}
    result = {"clean_runs": 384, "clean_controls_unchanged": True, "summary": summary,
              "worst_full_repair": sorted(pairs, key=lambda row: row["gain"])[:20],
              "worst_cash_advance": sorted(pairs, key=lambda row: row["cash_gain"])[:20], "pairs": pairs}
    (root / "ANALYSIS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
