"""Build a compact source archive and stage it against persistent root resources."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
REPO = EXP.parents[2]


def main():
    artifacts = EXP / "artifacts"
    artifacts.mkdir(exist_ok=True)
    staged_repo = EXP / "runs/component_clean_build_001/root"
    staged_repo.mkdir(parents=True, exist_ok=False)
    files = [EXP / name for name in ["CMakeLists.txt", "API.md", "HANDOFF.md", "DESIGN.md", "PROTOCOL.md", "COMPONENT_MANIFEST.json"]]
    files += [path for directory in ["include", "source", "examples"] for path in (EXP / directory).rglob("*") if path.is_file()]
    files.append(EXP / "scripts/optimize_placement.py")
    pairs = [(path, path.relative_to(REPO)) for path in files]
    pairs.append((EXP / "PACKAGE_README.md", EXP.relative_to(REPO) / "README.md"))
    archive = artifacts / "placement_component_source.tar.gz"
    with tarfile.open(archive, "w:gz") as output:
        for source, relative in pairs:
            output.add(source, arcname=str(relative), recursive=False)
    with tarfile.open(archive) as package:
        package.extractall(staged_repo, filter="data")
    for name in ["day_solver", "fast_day_solver_estimator", "fast_game_engine", "agents"]:
        (staged_repo / name).symlink_to(REPO / name, target_is_directory=True)
    report = {"archive": str(archive.relative_to(EXP)), "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(), "bytes": archive.stat().st_size, "files": len(pairs),
        "source_files_sha256": {str(relative): hashlib.sha256(source.read_bytes()).hexdigest() for source, relative in pairs},
        "staged_repository": str(staged_repo.relative_to(EXP)), "persistent_root_dependencies": ["day_solver", "fast_day_solver_estimator", "fast_game_engine", "agents"],
        "scope": "component sources and runnable example; large replay/benchmark artifacts are intentionally outside this source archive"}
    (artifacts / "PACKAGE.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "source_files_sha256"}))


if __name__ == "__main__":
    main()
