"""Transfer a fixed motif/bank across one related development family."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/transfer_panel_001"


def main():
    courses = json.loads((EXP / "runs/source_courses/MANIFEST.json").read_text())["courses"]
    cases = [row for row in courses if row["team"] in ["DeeperNet", "mtmr_s1"]]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    prior = json.loads((EXP / "runs/swap_certificates_001/SUMMARY.json").read_text())
    banks = [EXP / "runs/swap_certificates_001" / row["id"] for row in prior if row["complete"]]
    OUTPUT.mkdir(exist_ok=False)
    names = ["transfer_certificates", "certify_course", "replay_course"]
    for name in names:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    layouts = {"source": EXP / "runs/swap_probes_002/107269880_1/source.layout.txt",
               "swap": EXP / "runs/swap_probes_002/107269880_1/cow_25_sheep_36.layout.txt"}
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": cases, "banks": [str(path.relative_to(EXP)) for path in banks],
        "layouts": {key: str(value.relative_to(EXP)) for key, value in layouts.items()}, "workers": 2, "missing_day_seconds": 9, "query_seconds": 3,
        "claim_scope": "related-family transfer; discovery courses 107269880_1 and 107270694_0 are not new transfer tests",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in names}}, indent=2) + "\n")
    tasks = [(case, method) for case in cases for method in layouts]
    def run(task):
        case, method = task
        folder = OUTPUT / f"{case['episode']}_{case['seat']}_{method}"
        warm = folder.with_name(folder.name + "_warm")
        with folder.with_suffix(".log").open("w") as stream:
            transferred = subprocess.run([str(OUTPUT / "transfer_certificates"), str(EXP / case["course"]), str(layouts[method]), str(warm),
                                          *map(str, banks)], stdout=stream, stderr=subprocess.STDOUT)
            if transferred.returncode:
                return {**case, "method": method, "error": "transfer failed"}
            completed = subprocess.run([str(OUTPUT / "certify_course"), str(EXP / case["course"]), str(layouts[method]), str(folder), "9", "3", str(warm)],
                                       stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "method": method, "returncode": completed.returncode, "output": str(folder.relative_to(EXP)),
               "transfer": json.loads((warm / "SUMMARY.json").read_text())}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        if row.get("complete"):
            for mode in ["native", "fixed_shops"]:
                report = folder / f"REPLAY_{mode}.json"
                with (folder / f"replay_{mode}.log").open("w") as stream:
                    replay = subprocess.run([str(OUTPUT / "replay_course"), str(EXP / traces[case["episode"]]), str(case["seat"]), str(folder),
                        str(layouts[method]), str(report), mode], stdout=stream, stderr=subprocess.STDOUT)
                row[f"replay_{mode}"] = json.loads(report.read_text()) if report.exists() else {"returncode": replay.returncode}
            row["full_engine_verified"] = all(row[f"replay_{mode}"].get("valid", False) for mode in ["native", "fixed_shops"])
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row
    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
