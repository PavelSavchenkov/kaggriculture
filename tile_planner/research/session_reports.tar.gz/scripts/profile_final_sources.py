"""Final-source placement roles and actual cross-quadrant service."""
import csv
import json
import statistics
import subprocess
from collections import defaultdict
from pathlib import Path

from profile_validation_courses import distance, role, signature

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "research/final_source_profiles"


def main():
    OUTPUT.mkdir(exist_ok=False)
    cases = json.loads((EXP / "runs/final_panel_001/IMPORTS.json").read_text())
    profiles = []
    for case in cases:
        source = EXP / case["folder"] / "source"
        metadata = json.loads((source / "SUMMARY.json").read_text())
        assert metadata["source_parity"] and metadata["valid_day_contracts"] == 30
        output = OUTPUT / f"{case['episode']}_{case['seat']}"
        trace = EXP / "research/final_placement_traces_v2" / f"{case['episode']}.txt"
        subprocess.run([str(EXP / "build/profile_trace"), str(trace), str(case["seat"]), str(output)], check=True)
        workers = list(csv.DictReader((output / "workers.csv").open()))
        productive = [row for row in workers if int(row["field_actions"]) > 0]
        mixed = [row for row in productive if int(row["quadrants"]) > 1]
        roles = [set() for _ in range(100)]; radii = defaultdict(list); calendars = []; work_calendars = []
        for day in range(30):
            problem = json.loads((source / f"{day:02d}/problem.json").read_text())
            snapshot = []
            for cell, tile in enumerate(problem["start"]["managed_tiles"]):
                label = role(tile["state"]); snapshot.append(label)
                if label:
                    roles[cell].add(label); radii[label.split("_")[0]].append(distance(cell))
            calendars.append(snapshot)
            work_calendars.append(sorted((work["tile"], [(a["op"], a["arg"], a["output_quantity"]) for a in work["actions"]]) for work in problem["tile_work"]))
        used = [values for values in roles if values]
        profiles.append({"episode": case["episode"], "seat": case["seat"], "team": case["team"], "team_id": case["team_id"],
            "used_tiles": len(used), "single_species_fraction": sum(len(values) == 1 for values in used) / len(used),
            "single_crop_or_animal_role_fraction": sum(len({v.split("_")[0] for v in values}) == 1 for values in used) / len(used),
            "mean_animal_radius": statistics.mean(radii["animal"]), "mean_crop_radius": statistics.mean(radii["crop"]),
            "productive_worker_days": len(productive), "mixed_quadrant_worker_days": len(mixed),
            "mixed_worker_fraction": len(mixed) / len(productive),
            "mixed_worker_field_fraction": sum(int(row["field_actions"]) for row in mixed) / sum(int(row["field_actions"]) for row in productive),
            "work_calendar_hash": signature(work_calendars), "early_work_hash": signature(work_calendars[:3]),
            "roles_hash": signature(calendars), "daily_roles": calendars, "tile_roles": [sorted(values) for values in roles]})
    summary = {}
    for team in sorted({case["team"] for case in profiles}):
        rows = [row for row in profiles if row["team"] == team]
        summary[team] = {"cases": len(rows), **{key: statistics.mean(row[key] for row in rows) for key in
            ["single_species_fraction", "single_crop_or_animal_role_fraction", "mean_animal_radius", "mean_crop_radius", "mixed_worker_fraction", "mixed_worker_field_fraction"]},
            "distinct_work_calendars": len({row["work_calendar_hash"] for row in rows}), "distinct_early_work": len({row["early_work_hash"] for row in rows})}
    (OUTPUT / "PROFILES.json").write_text(json.dumps(profiles, indent=2) + "\n")
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
