"""Execute each frozen demand decision at its actual observation time."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
REFERENCE = EXP / "runs/probe_live_001"
OUTPUT = EXP / "runs/conditional_live_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    shutil.copy2(REFERENCE / "BANK.txt", OUTPUT / "BANK.txt")
    rules = json.loads((REFERENCE / "CONDITIONAL_RULES.json").read_text())
    tasks = [{**rule, "shop_seed": seed} for rule in rules["rules"] for seed in rules["test_shop_seeds"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "information": "only actual own observation and currently revealed shops at the decision day; earlier lives cannot change",
        "claim": "runtime decision must exactly match the already measured selected branch's final cash and bill",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]}}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['id']}_{task['shop_seed']}"
        source = EXP / "runs/life_probes_001/0"
        alternate = EXP / "runs/life_probes_001" / task["id"] / "assignment.txt"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(OUTPUT / "compile_cold"), str(source / "INPUT.plan"), str(folder), str(source / "assignment.txt"),
                "6", "2", "4001", "0.005", "--opponent", "public_router", "--shop_seed", str(task["shop_seed"]),
                "--bank", str(OUTPUT / "BANK.txt"), "--refine", "0", "--alternate", str(alternate),
                "--decision_day", str(task["decision_day"]), "--milk_threshold", str(task["threshold"])], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            selected = (folder / "decisions.csv").read_text().splitlines()[1].split(",")[-1] == "1"
            branch = task["id"] if selected else "0"
            expected = json.loads((REFERENCE / f"shared_{branch}_4001_0_dawn_{task['shop_seed']}" / "RESULT.json").read_text())
            row["selected"] = selected
            row["matches_branch"] = all(row[key] == expected[key] for key in ["hire_bill", "cash", "opponent_cash"])
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), "4001", "0.005", "0", str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
