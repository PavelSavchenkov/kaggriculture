"""Post-freeze diagnosis: deepen the first two unresolved placement queries."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/final_deeper_points_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    rows = json.loads((EXP / "runs/final_panel_001/BOUNDED.json").read_text()) + json.loads((EXP / "runs/distinct_bounded_panel_001/SUMMARY.json").read_text())
    cases = [row for row in rows if row["mode"] == "search"]
    tasks = []
    for case in cases:
        source = EXP / case["output"]
        name = source.parent.name if "episode" in case else case["case"].split("/")[0]
        tool = OUTPUT / name / "solve_point"
        tool.parent.mkdir()
        shutil.copy2(source / "solve_point", tool)
        selected = []
        controls = set()
        for event in case["events"]:
            if not event["label"].startswith("point_"):
                continue
            probe = event["label"].removeprefix("point_")
            points = list((source / "points" / probe).glob("*/SUMMARY.json"))
            if len(points) != 1:
                continue
            prior = json.loads(points[0].read_text())
            if prior["status"] != "unknown":
                continue
            selected.append({"case": name, "kind": "candidate", "probe": probe, "day": prior["day"], "workers": prior["workers"], "prior_seconds": prior["seconds"], "prior_status": prior["status"], "source": str(source / "proposals" / probe / f"{prior['day']:02d}"), "bounded_source": str(source), "tool": str(tool)})
            controls.add((prior["day"], prior["workers"]))
            if len(selected) == 2:
                break
        tasks += selected
        for day, workers in sorted(controls):
            tasks.append({"case": name, "kind": "control", "probe": "unchanged", "day": day, "workers": workers, "source": str(source / "incumbent" / f"{day:02d}"), "bounded_source": str(source), "tool": str(tool)})
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"scope": "post-freeze headroom diagnosis only; does not revise frozen outcomes or fit proposal rules",
        "selection": "first two actually queried placement proposals per case whose saved point status is UNKNOWN, in original query order; unchanged-layout control for every corresponding day/workforce",
        "seconds": 30, "external_timeout": 60, "workers": 4, "tasks": tasks,
        "solver_sha256": {str(path.relative_to(OUTPUT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in OUTPUT.glob("*/solve_point")}}, indent=2) + "\n")

    def run(task):
        parent = OUTPUT / task["case"] / f"{task['kind']}_{task['probe']}_{task['workers']}"
        folder = parent / f"{task['day']:02d}"
        parent.mkdir(parents=True, exist_ok=True)
        with (parent / f"{task['day']:02d}.log").open("w") as stream:
            result = subprocess.run(list(map(str, [task["tool"], task["source"], task["day"], task["workers"], 30, folder])), stdout=stream, stderr=subprocess.STDOUT, timeout=60)
        row = {**task, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row["result"] = json.loads((folder / "SUMMARY.json").read_text())
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps({key: value for key, value in row.items() if key not in ["source", "bounded_source", "tool"]}), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        result = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
