"""Validate peak-day successes as whole courses against a strengthened control."""
import csv
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/probe_courses_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    for name in ["compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, OUTPUT / name)
    points = json.loads((EXP / "runs/life_points_001/SUMMARY.json").read_text())
    positive = [row for row in points if row.get("status") == "feasible"]
    bank = (EXP / "runs/cold_bank_001.txt").read_text().splitlines()
    bank.append(str(EXP / "runs/cold_incumbent_001"))
    for row in positive:
        source = EXP / "runs/life_points_001" / f"{row['id']}_{row['day']}"
        course = OUTPUT / "point_bank" / row["id"]
        folder = course / str(row["day"])
        shutil.copytree(source, folder)
        bank.append(str(course))
    (OUTPUT / "BANK.txt").write_text("\n".join(dict.fromkeys(bank)) + "\n")
    probes = {row["id"]: row for row in csv.DictReader((EXP / "runs/life_probes_001/probes.csv").open())}
    ids = ["0", *sorted({row["id"] for row in positive}, key=int)]
    tasks = [{**probes[i], "seed": 1009, "shop_seed": 3001, "weed": 0, "opponent": "pass"} for i in ids]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "day_seconds": 9, "query_seconds": 3, "refine": "all days, every candidate and control",
        "shared_bank": "original development courses plus every feasible intervention point; cheaper strict-valid witnesses may transfer back to the control",
        "selection": "all interventions with a feasible 13-worker peak point, plus original",
        "scope": "development headroom, not a learned selector or independent final result",
        "binary_sha256": {name: hashlib.sha256((OUTPUT / name).read_bytes()).hexdigest() for name in ["compile_cold", "export_calendar"]}}, indent=2) + "\n")

    def run(task):
        source = EXP / "runs/life_probes_001" / task["id"]
        folder = OUTPUT / task["id"]
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"),
                str(source / "INPUT.plan"), str(folder), str(source / "assignment.txt"), "9", "3", "1009", "0", "--bank", str(OUTPUT / "BANK.txt"),
                "--shop_seed", "3001"], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        if row.get("complete"):
            with (folder / "calendar.log").open("w") as stream:
                check = subprocess.run([str(OUTPUT / "export_calendar"), str(folder), "1009", "0", "0", str(folder / "calendar")], stdout=stream, stderr=subprocess.STDOUT)
            row["calendar_verified"] = check.returncode == 0
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
