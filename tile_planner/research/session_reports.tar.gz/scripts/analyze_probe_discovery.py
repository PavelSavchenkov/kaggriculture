"""Inspect only the prespecified discovery half of the shared-shop panel."""
import json
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
RUN = EXP / "runs/probe_live_001"
TRAIN = [7001, 7013, 7027, 7043, 7057, 7079, 7103, 7121]
# Frozen official engine definitions: item bit masks and town multipliers.
MILK_SHOPS = {3, 5, 6}
WOOL_SHOPS = {7}
MULTIPLIER = [1, 1, 1, 1, 2, 1, 1, 2]


def main():
    rows = []
    for seed in TRAIN:
        for finance in ["dawn", "immediate_goods"]:
            prefix = f"shared_0_4001_0_{finance}_{seed}"
            base = json.loads((RUN / prefix / "RESULT.json").read_text())
            shops = [list(map(int, line.split())) for line in (RUN / prefix / "shops.txt").read_text().splitlines()]
            for id_, day in [("1950", 20), ("2717", 4), ("2759", 10), ("3125", 16)]:
                row = json.loads((RUN / f"shared_{id_}_4001_0_{finance}_{seed}" / "RESULT.json").read_text())
                current = shops[day * 24][2:]
                milk = sum(MULTIPLIER[s] for s in current if s in MILK_SHOPS)
                wool = sum(MULTIPLIER[s] for s in current if s in WOOL_SHOPS)
                rows.append({"id": id_, "shop_seed": seed, "finance": finance, "decision_day": day, "revealed_shops": current,
                    "milk_demand": milk, "wool_demand": wool, "complete": row["complete"] and base["complete"],
                    "hire_saving": base["hire_bill"] - row["hire_bill"], "cash_gain": row["cash"] - base["cash"],
                    "margin_gain": row["cash"] - row["opponent_cash"] - base["cash"] + base["opponent_cash"]})
    summary = {"scope": "discovery seeds only; reserved test outcomes were not read", "rows": rows}
    (RUN / "DISCOVERY.json").write_text(json.dumps(summary, indent=2) + "\n")
    for id_ in ["1950", "2717", "2759", "3125"]:
        selected = [r for r in rows if r["id"] == id_ and r["finance"] == "dawn"]
        print(id_, [(r["shop_seed"], r["milk_demand"], r["wool_demand"], r["hire_saving"], r["cash_gain"], r["margin_gain"]) for r in selected])


if __name__ == "__main__":
    main()
