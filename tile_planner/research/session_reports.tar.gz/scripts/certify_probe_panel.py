"""Bounded exact counterfactual panel, with complete-game checks after certificates."""
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/swap_certificates_001"


def execute(task):
    folder = OUTPUT / task["id"]
    log = folder.with_suffix(".log")
    command = [str(EXP / "build/certify_course"), str(EXP / task["course"]), str(EXP / task["layout"]), str(folder), "9", "3"]
    started = datetime.now(timezone.utc).isoformat()
    with log.open("w") as stream:
        completed = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    row = {**task, "started_utc": started, "completed_utc": datetime.now(timezone.utc).isoformat(), "returncode": completed.returncode}
    summary = folder / "SUMMARY.json"
    if summary.exists():
        row.update(json.loads(summary.read_text()))
    if row.get("complete"):
        for mode in ["native", "fixed_shops"]:
            report = folder / f"REPLAY_{mode}.json"
            with (folder / f"replay_{mode}.log").open("w") as stream:
                replay = subprocess.run([str(EXP / "build/replay_course"), str(EXP / task["trace"]), str(task["seat"]),
                    str(folder), str(EXP / task["layout"]), str(report), mode], stdout=stream, stderr=subprocess.STDOUT)
            row[f"replay_{mode}"] = json.loads(report.read_text()) if report.exists() else {"returncode": replay.returncode, "error": "no report"}
        row["full_engine_verified"] = all(row[f"replay_{mode}"].get("valid", False) for mode in ["native", "fixed_shops"])
    folder.mkdir(exist_ok=True)
    (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    return row


def main():
    probes = json.loads((EXP / "runs/swap_probes_002/SUMMARY.json").read_text())
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    tasks = []
    for case in probes:
        choices = [("source", "source")]
        choices += [("predicted", case["top_predicted"][0]["name"])]
        if case["top_retained_improving"]:
            choices += [("retained", case["top_retained_improving"][0]["name"])]
        seen = set()
        for method, choice in choices:
            if choice in seen:
                continue
            seen.add(choice)
            tasks.append({"id": f"{case['episode']}_{case['seat']}_{method}", "team": case["team"], "episode": case["episode"],
                          "seat": case["seat"], "method": method, "intervention": choice, "course": case["course"],
                          "layout": f"{case['output']}/{choice}.layout.txt", "trace": traces[case["episode"]]})
    OUTPUT.mkdir(exist_ok=False)
    protocol = {"tasks": tasks, "per_day_seconds": 9, "query_seconds": 3, "workers": 4, "solver_threads": 1,
                "kind": "development headroom, not selector promotion", "binary_sha256": {
                    name: hashlib.sha256((EXP / "build" / name).read_bytes()).hexdigest() for name in ["certify_course", "replay_course"]}}
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps(protocol, indent=2) + "\n")
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(execute, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
