"""Describe live transfer without conflating missing-day solve budgets."""
import collections
import json
import statistics
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    root = EXP / "runs/cold_live_001"
    rows = json.loads((root / "SUMMARY.json").read_text())
    assert len(rows) == 96 and all(row.get("complete") and row.get("calendar_verified") for row in rows)
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row["case"], row["method"], row["finance"]].append(row)
    summary = []
    for (case, method, finance), values in sorted(groups.items()):
        summary.append({"case": case, "method": method, "finance": finance, "count": len(values),
            "mean_bill": statistics.mean(row["hire_bill"] for row in values), "mean_cash": statistics.mean(row["cash"] for row in values),
            "mean_process_seconds": statistics.mean(row["process_seconds"] for row in values), "mean_queries": statistics.mean(row["queries"] for row in values),
            "mean_bank_matches": statistics.mean(row["bank_matches"] for row in values), "weed_repairs": sum(row["bank_weed_repairs"] for row in values)})
    pairs = []
    index = {(row["case"], row["method"], row["seed"], row["seat"], row["finance"]): row for row in rows}
    for candidate in rows:
        if candidate["method"] != "local_lives":
            continue
        method = "animals" if candidate["case"] == "expanding_mixed" else "nearest"
        base = index[candidate["case"], method, candidate["seed"], candidate["seat"], candidate["finance"]]
        pairs.append({"case": candidate["case"], "seed": candidate["seed"], "seat": candidate["seat"], "finance": candidate["finance"],
            "hire_saving": base["hire_bill"] - candidate["hire_bill"], "cash_gain": candidate["cash"] - base["cash"],
            "base_queries": base["queries"], "candidate_queries": candidate["queries"]})
    result = {"complete": 96, "calendar_verified": 96, "groups": summary, "pairs": pairs,
              "claim_scope": "functional transfer; unequal missing-day queries require matched refinement controls for quality claims"}
    (root / "ANALYSIS.json").write_text(json.dumps(result, indent=2) + "\n")
    for row in summary:
        print(row["case"], row["method"], row["finance"], "bill", row["mean_bill"], "cash", row["mean_cash"],
              "seconds", round(row["mean_process_seconds"], 3), "queries", row["mean_queries"], "matches", row["mean_bank_matches"])


if __name__ == "__main__":
    main()
