"""Compare emitted worker commands with public tapes; no agent code executes."""
import argparse
import json
import statistics
import sys
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXP.parents[2]))
from fast_game_engine.export_trace import enc_unit


def normalize(units):
    result = [(op, arg if op in (5, 7, 8) else 0, n if op in (5, 7) else 0) for op, arg, n in units]
    while len(result) > 1 and result[-1][0] == 0:
        result.pop()
    return tuple(result)


def from_trace(path, seat):
    lines = path.read_text().splitlines()
    result = []
    for step in range(719):
        values = list(map(int, lines[3 + 2 * step + seat].split()))
        result.append(normalize([tuple(values[2 + 3 * u:5 + 3 * u]) for u in range(values[0])]))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--final", action="store_true")
    args = parser.parse_args()
    packed = json.loads((EXP / "research/source_review/shop_router_0909_tapes.json").read_text())
    tapes = [[normalize([enc_unit(action.get("farmer")), *(enc_unit(a) for a in action.get("hands", []))])
              for action in tape[:719]] for tape in packed]
    assert all(len(tape) == 719 for tape in tapes)
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"] + json.loads((EXP / "research/validation_placement_traces_v1/MANIFEST.json").read_text())["games"]
    if args.final:
        games += json.loads((EXP / "research/final_placement_traces_v2/MANIFEST.json").read_text())["games"]
    rows = []
    emitted = []
    for game in games:
        for hero in game["seats"]:
            commands = from_trace(EXP / game["trace"], hero["seat"])
            scores = [sum(a == b for a, b in zip(commands, tape)) / 719 for tape in tapes]
            best = max(range(len(scores)), key=scores.__getitem__)
            rows.append({**hero, "episode": game["episode"], "public_tape": best, "exact_worker_turn_fraction": scores[best],
                         "prefix_144_fraction": sum(a == b for a, b in zip(commands[:144], tapes[best][:144])) / 144})
            emitted.append(commands)
    nearest = []
    for i, row in enumerate(rows):
        comparisons = [(sum(a == b for a, b in zip(emitted[i], emitted[j])) / 719, j)
                       for j in range(len(rows)) if rows[j]["team_id"] != row["team_id"]]
        score, j = max(comparisons)
        nearest.append({"case": f"{row['episode']}_{row['seat']}", "team": row["team"], "nearest_other_team": rows[j]["team"],
                        "other_case": f"{rows[j]['episode']}_{rows[j]['seat']}", "exact_worker_turn_fraction": score})
    summary = {}
    for team in sorted({row["team"] for row in rows}):
        cases = [row for row in rows if row["team"] == team]
        summary[team] = {"public_tape_match_mean": statistics.mean(row["exact_worker_turn_fraction"] for row in cases),
                         "public_tape_match_max": max(row["exact_worker_turn_fraction"] for row in cases),
                         "public_tapes": sorted({row["public_tape"] for row in cases}),
                         "other_team_match_max": max(row["exact_worker_turn_fraction"] for row in nearest if row["team"] == team)}
    output = EXP / "research/source_review" / ("FINAL_TAPE_FAMILY_AUDIT.json" if args.final else "VALIDATION_TAPE_FAMILY_AUDIT.json")
    output.write_text(json.dumps({"metric": "exact normalized full worker-command tuple per turn; orders excluded; trailing PASS ignored", "summary": summary,
                                 "public_matches": rows, "nearest_other_teams": nearest}, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
