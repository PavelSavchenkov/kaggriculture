import json
import subprocess
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
rows = json.loads((EXP / "runs/source_courses/MANIFEST.json").read_text())["courses"]
courses = [EXP / row["course"] for row in rows if row.get("valid_day_contracts") == 30]
subprocess.run([str(EXP / "build/check_estimator_cache"), str(EXP / "runs/cache_check_001.json"), "128", *map(str, courses)], check=True)
