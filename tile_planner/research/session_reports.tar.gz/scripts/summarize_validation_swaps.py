"""Report only full-game outcomes; separate source refinement from placement."""
import json
from collections import Counter, defaultdict
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    folder = EXP / "runs/validation_swaps_001"
    rows = json.loads((folder / "SUMMARY.json").read_text())
    groups = defaultdict(dict)
    for row in rows:
        groups[(row["episode"], row["seat"])][row["method"]] = row
    courses = []
    for (episode, seat), methods in sorted(groups.items()):
        control = methods["source"]
        original_bill = next((row["replay_native"]["source_hire_bill"] for row in methods.values() if row.get("full_engine_verified")), None)
        valid_control = control.get("full_engine_verified", False)
        # A failed replay's partial hire bill is not a source final bill.
        control_bill = control["replay_native"]["candidate_hire_bill"] if valid_control else original_bill
        comparisons = []
        for method, row in methods.items():
            valid = row.get("full_engine_verified", False)
            final_bill = row["replay_native"]["candidate_hire_bill"] if valid else None
            comparisons.append({"method": method, "intervention": row["intervention"], "physical_complete": row.get("complete", False),
                "full_valid": valid, "hire_bill": final_bill,
                "saving_vs_refined_control": control_bill - final_bill if valid and valid_control else None,
                "saving_vs_original": row["replay_native"]["hire_saving"] if valid else None,
                "failure": row.get("replay_native", {}).get("failure") if row.get("complete") else "incomplete_physical_certificate"})
        courses.append({"episode": episode, "seat": seat, "team": control["team"], "refined_control_valid": valid_control, "comparisons": comparisons})
    methods = {}
    for method in ["source", "predicted", "retained", "random"]:
        selected = [r for c in courses for r in c["comparisons"] if r["method"] == method]
        gains = [r["saving_vs_refined_control"] for r in selected if r["saving_vs_refined_control"] is not None]
        methods[method] = {"attempted": len(selected), "physical_complete": sum(r["physical_complete"] for r in selected),
            "full_valid": sum(r["full_valid"] for r in selected), "valid_paired_controls": len(gains),
            "wins": sum(x > 0 for x in gains), "ties": sum(x == 0 for x in gains), "losses": sum(x < 0 for x in gains),
            "paired_savings": gains, "mean_paired_saving": sum(gains) / len(gains) if gains else None,
            "failures": dict(Counter(r["failure"] for r in selected if not r["full_valid"]))}
    report = {"methods": methods, "courses": courses,
        "interpretation": "valid paired subsets are selected by completion; report coverage and do not interpret their mean as unconditional benefit. Failed controls retain the separately verified original source. Teams are mostly related public-tape variants."}
    (folder / "ANALYSIS.json").write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(methods, indent=2))


if __name__ == "__main__":
    main()
