"""Run the C++ source profiler and summarize shared quadrant service."""
import collections
import csv
import json
import statistics
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def profile(entry):
    game, hero = entry
    output = EXP / "research" / "trace_profiles" / f"{game['episode']}_{hero['seat']}"
    if not (output / "days.csv").exists():
        subprocess.run([str(EXP / "build/profile_trace"), str(EXP / game["trace"]), str(hero["seat"]), str(output)], check=True)
    workers = list(csv.DictReader((output / "workers.csv").open()))
    days = list(csv.DictReader((output / "days.csv").open()))
    return {**hero, "episode": game["episode"], "workers": workers, "days": days}


def main():
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    entries = [(game, hero) for game in games if game["status"] == "exported_unverified" for hero in game["seats"]]
    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(profile, entries))
    teams = collections.defaultdict(list)
    for row in rows:
        teams[row["team"]].append(row)
    summary = {}
    for team, cases in sorted(teams.items()):
        workers = [worker for case in cases for worker in case["workers"]]
        both = [day for case in cases for day in case["days"] if int(day["cows"]) and int(day["sheep"])]
        demand_groups = {}
        for label, predicate in [("milk_higher", lambda d: int(d["milk_demand"]) > int(d["wool_demand"])),
                                 ("wool_higher", lambda d: int(d["milk_demand"]) < int(d["wool_demand"])),
                                 ("equal", lambda d: int(d["milk_demand"]) == int(d["wool_demand"]))]:
            subset = [day for day in both if predicate(day)]
            demand_groups[label] = {"farm_days": len(subset), "cow_minus_sheep_radius":
                statistics.mean(float(d["cow_radius"]) - float(d["sheep_radius"]) for d in subset) if subset else None}
        summary[team] = {"productive_worker_days": len(workers),
                         "multi_quadrant_fraction": sum(int(w["quadrants"]) > 1 for w in workers) / len(workers),
                         "field_actions_on_multi_quadrant_workers_fraction": sum(int(w["field_actions"]) for w in workers if int(w["quadrants"]) > 1) / sum(int(w["field_actions"]) for w in workers),
                         "mean_quadrant_crossings": statistics.mean(int(w["crossings"]) for w in workers),
                         "descriptive_demand_groups_not_causal": demand_groups}
    output = EXP / "research/trace_profiles/SUMMARY.json"
    output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
