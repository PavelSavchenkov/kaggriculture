"""Compare each repair against the same faults and queue-only baseline."""
import argparse
import collections
import csv
import json
import statistics
from pathlib import Path
from summarize_repairs import complete

EXP = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", default="repair_panel_002")
    args = parser.parse_args()
    root = EXP / "runs" / args.round
    cases = json.loads((root / "SUMMARY.json").read_text())
    assert len(cases) == 48 and all(case["returncode"] == 0 for case in cases)
    groups = collections.defaultdict(list)
    pairs = []
    for case in cases:
        rows = list(csv.DictReader((EXP / case["output"] / "results.csv").open()))
        indexed = {(r["fault"], r["world"], r["mode"]): r for r in rows}
        modes = max(int(row["mode"]) for row in rows) + 1
        for base in rows:
            if base["mode"] != "0" or base["kind"] == "clean":
                continue
            variants = [indexed[base["fault"], base["world"], str(mode)] for mode in range(modes)]
            record = {"team": case["team"], "episode": case["episode"], "seat": case["seat"], "fault": int(base["fault"]),
                      "kind": base["kind"], "world": base["world"], "money": [float(row["money"]) for row in variants],
                      "complete": [complete(row) for row in variants], "failed_units": [int(row["failed_units"]) for row in variants],
                      "advanced_units": [int(row["advanced_units"]) for row in variants], "guard_rejections": [int(row.get("guard_rejections", 0)) for row in variants]}
            pairs.append(record)
            groups[base["world"], base["kind"]].append(record)
    summary = {}
    for (world, kind), rows in sorted(groups.items()):
        comparisons = {}
        for mode in range(modes):
            gains = [row["money"][mode] - row["money"][2] for row in rows]
            comparisons[str(mode)] = {"complete": sum(row["complete"][mode] for row in rows), "mean_gain_vs_queue": statistics.mean(gains),
                "median_gain_vs_queue": statistics.median(gains), "min": min(gains), "max": max(gains),
                "wins": sum(x > 0 for x in gains), "losses": sum(x < 0 for x in gains),
                "advanced_units": sum(row["advanced_units"][mode] for row in rows), "guard_rejections": sum(row["guard_rejections"][mode] for row in rows)}
        summary[f"{world}:{kind}"] = {"fault_instances": len(rows), "comparisons": comparisons}
    result = {"clean_controls_unchanged": True, "summary": summary, "pairs": pairs}
    (root / "ANALYSIS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
