"""Convert existing development biology into strict dated-lifetime inputs."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/replay_lives_002"


def main():
    cases = json.loads((EXP / "runs/source_courses_v2/MANIFEST.json").read_text())["courses"]
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/import_lives", OUTPUT / "import_lives")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": cases, "workers": 2,
        "contract": "same life births, successful service and harvest quantities, live dawn biological states and land purchase days",
        "retimed": "structure construction and independent weed clears are derived by the cold compiler; trades and workforce are not imported",
        "claim": "biological input extraction only; no financial or scheduling equivalence until full cold compilation",
        "binary_sha256": hashlib.sha256((OUTPUT / "import_lives").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        folder = OUTPUT / f"{case['episode']}_{case['seat']}"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(OUTPUT / "import_lives"), str(EXP / case["course"]), str(folder)], stdout=stream, stderr=subprocess.STDOUT)
        row = {"episode": case["episode"], "seat": case["seat"], "team": case["team"], "team_id": case["team_id"],
               "source_course": case["course"], "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=2) as pool:
        rows = list(pool.map(run, cases))
    (OUTPUT / "MANIFEST.json").write_text(json.dumps({"courses": rows}, indent=2) + "\n")


if __name__ == "__main__":
    main()
