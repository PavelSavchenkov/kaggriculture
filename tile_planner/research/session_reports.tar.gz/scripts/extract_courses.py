"""Extract replay courses with bounded subprocess concurrency."""
import argparse
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def extract(entry):
    game, hero = entry
    target = EXP / "runs" / "source_courses" / f"{game['episode']}_{hero['seat']}"
    target.parent.mkdir(exist_ok=True)
    summary = target / "SUMMARY.json"
    if summary.exists():
        result = json.loads(summary.read_text())
        return {**hero, "episode": game["episode"], "course": str(target.relative_to(EXP)), **result}
    log = target.with_suffix(".log")
    with log.open("w") as stream:
        run = subprocess.run([str(EXP / "build" / "extract_course"), str(EXP / game["trace"]),
                              str(hero["seat"]), str(target)], stdout=stream, stderr=subprocess.STDOUT)
    result = json.loads(summary.read_text()) if summary.exists() else {"error": log.read_text()[-4000:]}
    row = {**hero, "episode": game["episode"], "course": str(target.relative_to(EXP)), "returncode": run.returncode, **result}
    print(json.dumps(row), flush=True)
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    games = json.loads(args.manifest.read_text())["games"]
    entries = [(game, hero) for game in games if game["status"] == "exported_unverified" for hero in game["seats"]]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        rows = list(pool.map(extract, entries))
    (EXP / "runs" / "source_courses" / "MANIFEST.json").write_text(json.dumps({"courses": rows}, indent=2) + "\n")


if __name__ == "__main__":
    main()
