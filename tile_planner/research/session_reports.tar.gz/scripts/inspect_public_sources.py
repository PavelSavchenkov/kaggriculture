"""Extract literal source strings for review without executing notebook cells."""
import ast
import hashlib
import json
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]


def main():
    output = EXP / "research/source_review"
    output.mkdir(exist_ok=True)
    rows = []
    for notebook in (EXP / "research/notebooks").rglob("*.ipynb"):
        cells = json.loads(notebook.read_text())["cells"]
        for index, cell in enumerate(cells):
            if cell["cell_type"] != "code":
                continue
            source = "".join(cell["source"])
            if any(line.startswith(("%", "!")) for line in source.splitlines()):
                continue
            tree = ast.parse(source)
            for node in tree.body:
                if not isinstance(node, ast.Assign) or not isinstance(node.value, ast.Constant) or not isinstance(node.value.value, str):
                    continue
                names = [name.id for name in node.targets if isinstance(name, ast.Name)]
                if not any("SOURCE" in name.upper() or "AGENT_CODE" in name.upper() for name in names):
                    continue
                text = node.value.value
                if len(text) < 500:
                    continue
                slug = notebook.stem + "_" + names[0]
                target = output / f"{slug}.txt"
                target.write_text(text)
                rows.append({"notebook": str(notebook.relative_to(EXP)), "cell": index, "variable": names[0],
                             "review_text": str(target.relative_to(EXP)), "sha256": hashlib.sha256(text.encode()).hexdigest(),
                             "bytes": len(text.encode()), "executed": False})
    (output / "MANIFEST.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
