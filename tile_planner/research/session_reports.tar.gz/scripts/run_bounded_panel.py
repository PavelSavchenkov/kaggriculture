"""Frozen common-budget search versus fixed-layout refinement."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/bounded_panel_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    binaries = OUTPUT / "tools"; binaries.mkdir()
    for name in ["probe_lives", "solve_point", "pack_bank", "compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, binaries / name)
    launcher = OUTPUT / "optimize_placement.py"
    shutil.copy2(EXP / "scripts/optimize_placement.py", launcher)
    cases = ["expanding36", "expanding32", "wheat23", "mixed_delayed", "mixed_low_care", "carrot10"]
    tasks = [{"case": case, "mode": mode, "seconds": seconds, "seed": 9013, "objective": "cash"}
        for seconds in [90, 180] for case in cases for mode in ["search", "fixed"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4,
        "primary": "best complete own cash at a common total process budget; both modes retain the same supplied incumbent",
        "secondary": "hire cost, cash margin, complete Pareto alternatives, time to improvement and failed/timed-out candidates",
        "bank": "only the supplied incumbent and certificates discovered within this run; no favorable intervention bank",
        "scope": "development compositions, frozen algorithm; no independent leaderboard-family claim",
        "launcher_sha256": hashlib.sha256(launcher.read_bytes()).hexdigest(),
        "binary_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in binaries.iterdir()}}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['case']}_{task['mode']}_{task['seconds']}"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), "python", str(launcher),
                str(EXP / "runs/search_inputs_001" / task["case"]), str(folder), "--mode", task["mode"], "--seconds", str(task["seconds"]),
                "--seed", str(task["seed"]), "--objective", task["objective"], "--tools", str(binaries)], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "RESULT.json").exists():
            data = json.loads((folder / "RESULT.json").read_text())
            row.update({key: value for key, value in data.items() if key != "events"})
            row["events"] = len(data["events"])
            row["timeouts"] = sum(event["status"] == "timeout" for event in data["events"])
        if result.returncode:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
