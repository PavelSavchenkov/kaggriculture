"""Check all restored source contracts in the actual game engine."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/source_v2_replay_001"


def main():
    cases = json.loads((EXP / "runs/source_courses_v2/MANIFEST.json").read_text())["courses"]
    games = json.loads((EXP / "research/development_initial_traces_v1/MANIFEST.json").read_text())["games"]
    traces = {game["episode"]: game["trace"] for game in games}
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/replay_course", OUTPUT / "replay_course")
    layout = OUTPUT / "identity.layout.txt"
    layout.write_text(" ".join(map(str, range(100))) + "\n")
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"cases": cases, "workers": 4,
        "binary_sha256": hashlib.sha256((OUTPUT / "replay_course").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        report = OUTPUT / f"{case['episode']}_{case['seat']}.json"
        with report.with_suffix(".log").open("w") as stream:
            result = subprocess.run([str(OUTPUT / "replay_course"), str(EXP / traces[case["episode"]]), str(case["seat"]),
                str(EXP / case["course"]), str(layout), str(report), "native"], stdout=stream, stderr=subprocess.STDOUT)
        row = {"episode": case["episode"], "seat": case["seat"], "returncode": result.returncode}
        if report.exists():
            row.update(json.loads(report.read_text()))
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, cases))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps({"courses": len(rows), "valid": sum(row.get("valid", False) for row in rows)}))


if __name__ == "__main__":
    main()
