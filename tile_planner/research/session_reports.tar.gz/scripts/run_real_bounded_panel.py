"""Equal budgets on verified, fully refined real replay-derived plans."""
import argparse
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/real_bounded_panel_001"


def main():
    global OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()
    OUTPUT = args.output.resolve()
    cases = [row for row in json.loads((EXP / "runs/replay_cold_panel_001/SUMMARY.json").read_text())
        if row["method"] == "source_preparation_refine" and row.get("complete") and row.get("calendar_verified")]
    OUTPUT.mkdir(exist_ok=False)
    binaries = OUTPUT / "tools"; binaries.mkdir()
    for name in ["probe_lives", "solve_point", "pack_bank", "compile_cold", "export_calendar"]:
        shutil.copy2(EXP / "build" / name, binaries / name)
    launcher = OUTPUT / "optimize_placement.py"
    shutil.copy2(EXP / "scripts/optimize_placement.py", launcher)
    tasks = [{"team": case["team"], "episode": case["episode"], "seat": case["seat"], "source": case["output"], "mode": mode}
        for case in cases for mode in ["search", "fixed"]]
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "seconds": 180, "seed": 9013, "objective": "cash", "workers": 4,
        "primary": "best complete verified own cash from the same fully refined incumbent at a common 180-second internal budget",
        "bank": "only the incumbent and certificates discovered inside this run",
        "scope": "five successful development real-input compiles; excludes Mengfei whose baseline is incomplete; DeeperNet and mtmr_s1 are related",
        "launcher_sha256": hashlib.sha256(launcher.read_bytes()).hexdigest(),
        "binary_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in binaries.iterdir()}}, indent=2) + "\n")

    def run(task):
        folder = OUTPUT / f"{task['episode']}_{task['seat']}_{task['mode']}"
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), "python", str(launcher), str(EXP / task["source"]), str(folder),
                "--mode", task["mode"], "--seconds", "180", "--seed", "9013", "--objective", "cash", "--tools", str(binaries)], stdout=stream, stderr=subprocess.STDOUT)
        row = {**task, "returncode": result.returncode}
        if (folder / "RESULT.json").exists():
            data = json.loads((folder / "RESULT.json").read_text())
            row.update({key: value for key, value in data.items() if key != "events"})
            row["events"] = len(data["events"])
            row["timeouts"] = sum(event["status"] == "timeout" for event in data["events"])
        if result.returncode:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
