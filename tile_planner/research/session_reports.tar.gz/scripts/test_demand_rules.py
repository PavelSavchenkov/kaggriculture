"""Evaluate frozen small rules on the reserved shared-shop sequences."""
import json
import random
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
RUN = EXP / "runs/probe_live_001"
MILK_SHOPS = {3, 5, 6}


def main():
    protocol = json.loads((RUN / "CONDITIONAL_RULES.json").read_text())
    result = []
    for rule in protocol["rules"]:
        for finance in ["dawn", "immediate_goods"]:
            rows = []
            for seed in protocol["test_shop_seeds"]:
                base_path = RUN / f"shared_0_4001_0_{finance}_{seed}"
                base = json.loads((base_path / "RESULT.json").read_text())
                candidate = json.loads((RUN / f"shared_{rule['id']}_4001_0_{finance}_{seed}" / "RESULT.json").read_text())
                current = list(map(int, (base_path / "shops.txt").read_text().splitlines()[rule["decision_day"] * 24].split()))[2:]
                feature = sum(shop in MILK_SHOPS for shop in current)
                selected = feature >= rule["threshold"]
                if not base["complete"] or not candidate["complete"]:
                    raise RuntimeError("incomplete input in frozen demand-rule evaluation")
                gain = candidate["cash"] - base["cash"]
                margin = gain - candidate["opponent_cash"] + base["opponent_cash"]
                rows.append({"shop_seed": seed, "feature": feature, "selected": selected, "swap_cash_gain": gain,
                    "rule_cash_gain": gain if selected else 0, "rule_margin_gain": margin if selected else 0,
                    "hire_saving": base["hire_bill"] - candidate["hire_bill"] if selected else 0})
            rng = random.Random(9013)
            means = sorted(sum(rows[rng.randrange(len(rows))]["rule_cash_gain"] for _ in rows) / len(rows) for _ in range(10000))
            row = {"id": rule["id"], "finance": finance, "contexts": len(rows), "selected": sum(r["selected"] for r in rows),
                "rule_mean_cash_gain": sum(r["rule_cash_gain"] for r in rows) / len(rows),
                "rule_mean_margin_gain": sum(r["rule_margin_gain"] for r in rows) / len(rows),
                "always_swap_mean_cash_gain": sum(r["swap_cash_gain"] for r in rows) / len(rows),
                "oracle_mean_cash_gain": sum(max(0, r["swap_cash_gain"]) for r in rows) / len(rows),
                "negative_selected": sum(r["rule_cash_gain"] < 0 for r in rows),
                "bootstrap_95_interval": [means[250], means[9749]], "rows": rows}
            result.append(row)
            print(json.dumps({k: v for k, v in row.items() if k != "rows"}), flush=True)
    (RUN / "CONDITIONAL_TEST.json").write_text(json.dumps({"scope": "one composition, eight held-out shop sequences; not independent family generalization", "results": result}, indent=2) + "\n")


if __name__ == "__main__":
    main()
