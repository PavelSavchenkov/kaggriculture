"""Full-game cold placement headroom at fixed biological and land commitments."""
import hashlib
import json
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/cold_certificates_001"


def main():
    search = json.loads((EXP / "runs/life_search_001/SUMMARY.json").read_text())
    assert all(row["returncode"] == 0 for row in search)
    OUTPUT.mkdir(exist_ok=False)
    shutil.copy2(EXP / "build/compile_cold", OUTPUT / "compile_cold")
    shutil.copytree(EXP / "include", OUTPUT / "source/include")
    shutil.copy2(EXP / "source/compile_cold.cpp", OUTPUT / "source/compile_cold.cpp")
    tasks = []
    for row in search:
        seen = set()
        for method in ["nearest", "animals", "row", "local_lives", "equal_radius_lives"]:
            assignment = EXP / row["output"] / method / "assignment.txt"
            content = assignment.read_text().split()
            key = tuple(content)
            if key in seen:
                continue
            seen.add(key)
            for weeds in [0, 0.005]:
                tasks.append({"case": row["case"], "method": method, "assignment": str(assignment.relative_to(EXP)),
                    "seed": 1009, "weed_chance": weeds, "day_seconds": 10 if method in ["nearest", "animals"] else 9})
    (OUTPUT / "PROTOCOL.json").write_text(json.dumps({"tasks": tasks, "workers": 4, "query_seconds": 3,
        "objective": "same mandatory biological output, same land dates, same dawn finance policy; compare exact full-game hire bill and cash",
        "budget": "strong rules get 10 seconds/day; searched assignments get 9 seconds/day plus the frozen 30-second proposal search",
        "claim_scope": "candidate headroom on six synthetic compositions; one seed, live PASS opponent; not held-out policy promotion",
        "binary_sha256": hashlib.sha256((OUTPUT / "compile_cold").read_bytes()).hexdigest()}, indent=2) + "\n")

    def run(case):
        name = f"{case['case']}_{case['method']}_{'native' if case['weed_chance'] else 'no_weeds'}"
        folder = OUTPUT / name
        with folder.with_suffix(".log").open("w") as stream:
            result = subprocess.run(["/usr/bin/time", "-v", "-o", str(folder.with_suffix(".time.txt")), str(OUTPUT / "compile_cold"), case["case"],
                str(folder), str(EXP / case["assignment"]), str(case["day_seconds"]), "3", str(case["seed"]), str(case["weed_chance"])],
                stdout=stream, stderr=subprocess.STDOUT)
        row = {**case, "returncode": result.returncode, "output": str(folder.relative_to(EXP))}
        if (folder / "SUMMARY.json").exists():
            row.update(json.loads((folder / "SUMMARY.json").read_text()))
        else:
            row["error"] = folder.with_suffix(".log").read_text()[-2000:]
        folder.mkdir(exist_ok=True)
        (folder / "RESULT.json").write_text(json.dumps(row, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        return row

    with ThreadPoolExecutor(max_workers=4) as pool:
        rows = list(pool.map(run, tasks))
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
