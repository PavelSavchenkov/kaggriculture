"""Separate independent financial check of the frozen format speed panel."""
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
PANEL = EXP / "runs/bank_format_benchmark_001"


def main():
    rows = json.loads((PANEL / "SUMMARY.json").read_text())

    def check(row):
        folder = PANEL / f"{row['case']}_{row['format']}_{row['repeat']}"
        output = folder / "calendar_postcheck"
        with (folder / "calendar_postcheck.log").open("w") as stream:
            result = subprocess.run(list(map(str, [EXP / "build/export_calendar", folder, 1009, 0, 0, output])), stdout=stream, stderr=subprocess.STDOUT)
        return {"case": row["case"], "format": row["format"], "repeat": row["repeat"], "calendar_verified": result.returncode == 0, "output": str(output.relative_to(EXP))}

    with ThreadPoolExecutor(max_workers=2) as pool:
        checked = list(pool.map(check, rows))
    result = {"scope": "post-run independent financial check, separate from the original compile timings", "binary_sha256": hashlib.sha256((EXP / "build/export_calendar").read_bytes()).hexdigest(), "rows": checked, "all_verified": all(row["calendar_verified"] for row in checked)}
    (PANEL / "POSTCHECK.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"checked": len(checked), "all_verified": result["all_verified"]}))
    assert result["all_verified"]


if __name__ == "__main__":
    main()
