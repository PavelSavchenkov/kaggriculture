"""Exercise tiny-budget retention and rejection of a corrupted incumbent."""
import json
import shutil
import subprocess
import time
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/optimizer_budget_checks_002"


def main():
    OUTPUT.mkdir(exist_ok=False)
    source = EXP / "runs/search_inputs_001/carrot10"
    original = json.loads((source / "SUMMARY.json").read_text())
    reports = []
    for seconds in [0, 0.001, 0.01, 0.1, 1]:
        folder = OUTPUT / str(seconds)
        start = time.monotonic()
        result = subprocess.run(["python", str(EXP / "scripts/optimize_placement.py"), str(source), str(folder), "--seconds", str(seconds)], capture_output=True, text=True)
        report = json.loads((folder / "RESULT.json").read_text())
        assert result.returncode == 0, result.stderr
        assert report["status"] == "complete_incumbent_retained"
        assert report["hire_bill"] <= original["hire_bill"]
        assert (folder / report["best"] / "SUMMARY.json").exists()
        assert not (folder / "RESULT.tmp").exists()
        reports.append({"budget": seconds, "wall_seconds": time.monotonic() - start, "internal_seconds": report["elapsed_seconds"],
            "termination_reason": report["termination_reason"], "input_reverified": report["input_reverified"], "events": len(report["events"])})
    broken = OUTPUT / "broken_input"
    shutil.copytree(source, broken)
    (broken / "00/executable.actions.txt").write_text("invalid\n")
    folder = OUTPUT / "rejected"
    result = subprocess.run(["python", str(EXP / "scripts/optimize_placement.py"), str(broken), str(folder), "--seconds", "5"], capture_output=True, text=True)
    report = json.loads((folder / "RESULT.json").read_text())
    assert result.returncode != 0
    assert report["status"] == "invalid_incumbent" and report["best"] is None
    assert not report["complete_candidates"] and not report["pareto_candidates"]
    (OUTPUT / "SUMMARY.json").write_text(json.dumps({"checks": 6, "passed": True, "budgets": reports, "invalid_input_rejected": True}, indent=2) + "\n")
    print(json.dumps(reports, indent=2))


if __name__ == "__main__":
    main()
