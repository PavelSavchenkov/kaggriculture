"""Packed bank round-trip and malformed-input rejection."""
import json
import struct
import subprocess
from pathlib import Path

EXP = Path(__file__).resolve().parents[1]
OUTPUT = EXP / "runs/bank_format_checks_001"


def main():
    OUTPUT.mkdir(exist_ok=False)
    original = (EXP / "runs/cold_bank_001.bin").read_bytes()
    key_length = struct.unpack_from("<I", original, 12)[0]
    worker_offset = 16 + key_length
    mutations = {"truncated": original[:100], "extra": original + b"extra", "version": b"TPLBANK2" + original[8:],
        "oversized_key": original[:12] + struct.pack("<I", 65537) + original[16:]}
    for workers in [0, 41]:
        mutations[f"workers_{workers}"] = original[:worker_offset] + struct.pack("<I", workers) + original[worker_offset + 4:]
    rows = []
    validation = EXP / "runs/bank_validation_001.txt"
    for name, data in mutations.items():
        path = OUTPUT / (name + ".bin"); path.write_bytes(data)
        run = subprocess.run([str(EXP / "build/pack_bank"), str(path), str(OUTPUT / (name + "_out.bin")), str(validation)], capture_output=True, text=True)
        rows.append({"case": name, "rejected": run.returncode == 2, "error": run.stderr.strip()})
    run = subprocess.run([str(EXP / "build/pack_bank"), str(EXP / "runs/cold_bank_001.bin"), str(OUTPUT / "roundtrip.bin"), str(validation)], capture_output=True, text=True)
    identical = run.returncode == 0 and (OUTPUT / "roundtrip.bin").read_bytes() == original
    report = {"malformed": rows, "roundtrip_identical": identical, "roundtrip_check": run.stdout.strip()}
    (OUTPUT / "SUMMARY.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    if not identical or not all(row["rejected"] for row in rows):
        raise RuntimeError("packed bank validation failed")


if __name__ == "__main__":
    main()
